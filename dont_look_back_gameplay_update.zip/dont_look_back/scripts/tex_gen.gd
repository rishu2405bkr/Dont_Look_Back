extends RefCounted
# Procedural PBR textures (albedo + normal + roughness + ambient occlusion) and grime decals.
# Generated at runtime (in parallel worker threads), so there are no image files and no licensing issues.
# Lower S to 256 if the "Preparing textures..." step takes too long on a slow PC.

const S: int = 384
static var _cache: Dictionary = {}
static var _decals: Dictionary = {}
static var _cookie: ImageTexture = null
static var _mutex: Mutex = Mutex.new()

const KINDS: Array = ["plaster", "tile", "concrete", "metal", "wood", "crate", "skin"]


static func build_all() -> void:
    var results: Dictionary = {}
    if OS.has_feature("web"):
        for k in KINDS:
            _cache[k] = _to_tex(_make_images(String(k)))
    else:
        var ids: Array = []
        for k in KINDS:
            if _cache.has(k):
                continue
            var kind: String = String(k)
            var job := func() -> void:
                var imgs: Dictionary = _make_images(kind)
                _mutex.lock()
                results[kind] = imgs
                _mutex.unlock()
            ids.append(WorkerThreadPool.add_task(job, false, "texgen_" + kind))
        for id in ids:
            WorkerThreadPool.wait_for_task_completion(id)
        for k in results.keys():
            _cache[k] = _to_tex(results[k] as Dictionary)
    for k in KINDS:
        get_set(String(k))
    get_decal("blotch")
    get_decal("streak")
    get_decal("crack")
    get_decal("damp")
    get_flashlight_cookie()


static func get_set(kind: String) -> Dictionary:
    if _cache.has(kind):
        return _cache[kind] as Dictionary
    var d: Dictionary = _to_tex(_make_images(kind))
    _cache[kind] = d
    return d


static func _make_images(kind: String) -> Dictionary:
    match kind:
        "plaster": return _plaster()
        "tile": return _tile(Color(0.22, 0.24, 0.27), true)
        "concrete": return _tile(Color(0.34, 0.35, 0.37), false)
        "metal": return _metal()
        "wood": return _wood(false)
        "crate": return _wood(true)
        "skin": return _skin()
    return _plaster()


static func _to_tex(d: Dictionary) -> Dictionary:
    return {
        "albedo": ImageTexture.create_from_image(d["albedo"] as Image),
        "normal": ImageTexture.create_from_image(d["normal"] as Image),
        "rough": ImageTexture.create_from_image(d["rough"] as Image),
        "ao": ImageTexture.create_from_image(d["ao"] as Image),
    }


# ---------------- helpers ----------------

static func _noise_img(seed_v: int, freq: float, octaves: int, w: int, h: int) -> Image:
    var n := FastNoiseLite.new()
    n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    n.seed = seed_v
    n.frequency = freq
    n.fractal_type = FastNoiseLite.FRACTAL_FBM
    n.fractal_octaves = octaves
    var img: Image = n.get_seamless_image(w, h)
    img.convert(Image.FORMAT_L8)
    return img


# freq is given per 192 px so the look stays the same whatever S is
static func _noise(seed_v: int, freq: float, octaves: int) -> PackedByteArray:
    return _noise_img(seed_v, freq * 192.0 / float(S), octaves, S, S).get_data()


static func _streaks(seed_v: int, vertical: bool) -> PackedByteArray:
    var img: Image
    if vertical:
        img = _noise_img(seed_v, 0.08 * 192.0 / float(S), 3, S, 12)
    else:
        img = _noise_img(seed_v, 0.08 * 192.0 / float(S), 3, 12, S)
    img.resize(S, S, Image.INTERPOLATE_BILINEAR)
    return img.get_data()


static func _b(v: float) -> int:
    return clampi(int(v * 255.0), 0, 255)


static func _v(a: PackedByteArray, i: int) -> float:
    return float(a[i]) / 255.0


# thin ridge: 1 on the line where noise == 0.5, falling to 0 within `width`
static func _ridge(n: float, width: float) -> float:
    return clampf(1.0 - absf(n - 0.5) / width, 0.0, 1.0)


static func _normal(h: PackedByteArray, strength: float) -> PackedByteArray:
    var out := PackedByteArray()
    out.resize(S * S * 3)
    var k: float = strength / 255.0 * float(S) / 192.0
    for y in S:
        var ym: int = (y - 1 + S) % S
        var yp: int = (y + 1) % S
        for x in S:
            var xm: int = (x - 1 + S) % S
            var xp: int = (x + 1) % S
            var dx: float = (float(h[y * S + xm]) - float(h[y * S + xp])) * k
            var dy: float = (float(h[ym * S + x]) - float(h[yp * S + x])) * k
            var inv: float = 1.0 / sqrt(dx * dx + dy * dy + 1.0)
            var i: int = (y * S + x) * 3
            out[i] = _b(dx * inv * 0.5 + 0.5)
            out[i + 1] = _b(dy * inv * 0.5 + 0.5)
            out[i + 2] = _b(inv * 0.5 + 0.5)
    return out


# Cavity ambient occlusion: pixels lower than their surroundings get darker.
static func _cavity(h: PackedByteArray, reach: int, power: float) -> PackedByteArray:
    var out := PackedByteArray()
    out.resize(S * S)
    for y in S:
        var ya: int = (y - reach + S) % S
        var yb: int = (y + reach) % S
        for x in S:
            var xa: int = (x - reach + S) % S
            var xb: int = (x + reach) % S
            var avg: float = (float(h[y * S + xa]) + float(h[y * S + xb]) + float(h[ya * S + x]) + float(h[yb * S + x])) * 0.25
            var d: float = (float(h[y * S + x]) - avg) / 255.0
            out[y * S + x] = _b(clampf(1.0 + d * power, 0.25, 1.0))
    return out


static func _pack(alb: PackedByteArray, hgt: PackedByteArray, rgh: PackedByteArray, strength: float, ao_reach: int = 4, ao_power: float = 6.0) -> Dictionary:
    var nrm: PackedByteArray = _normal(hgt, strength)
    var ao: PackedByteArray = _cavity(hgt, ao_reach, ao_power)
    var a := Image.create_from_data(S, S, false, Image.FORMAT_RGB8, alb)
    var n := Image.create_from_data(S, S, false, Image.FORMAT_RGB8, nrm)
    var r := Image.create_from_data(S, S, false, Image.FORMAT_L8, rgh)
    var o := Image.create_from_data(S, S, false, Image.FORMAT_L8, ao)
    a.generate_mipmaps()
    n.generate_mipmaps()
    r.generate_mipmaps()
    o.generate_mipmaps()
    return {"albedo": a, "normal": n, "rough": r, "ao": o}


# ---------------- surface kinds ----------------

static func _plaster() -> Dictionary:
    var hn := _noise(11, 0.035, 5)
    var pn := _noise(12, 0.012, 3)
    var cn := _noise(13, 0.02, 2)
    var cn2 := _noise(113, 0.05, 2)
    var sn := _streaks(14, true)
    var fine := _noise(15, 0.35, 2)
    var peel := _noise(16, 0.018, 3)
    var stain := _noise(17, 0.008, 2)
    var alb := PackedByteArray()
    alb.resize(S * S * 3)
    var hgt := PackedByteArray()
    hgt.resize(S * S)
    var rgh := PackedByteArray()
    rgh.resize(S * S)
    for i in S * S:
        var h: float = _v(hn, i)
        var damp: float = smoothstep(0.55, 0.8, _v(pn, i))
        var streak: float = smoothstep(0.55, 0.9, _v(sn, i))
        var crack: float = maxf(_ridge(_v(cn, i), 0.012), _ridge(_v(cn2, i), 0.008) * 0.7)
        var f: float = _v(fine, i)
        var pl: float = smoothstep(0.66, 0.74, _v(peel, i))           # peeled paint patches
        var edge: float = pl * (1.0 - smoothstep(0.74, 0.8, _v(peel, i)))
        var tide: float = smoothstep(0.6, 0.85, _v(stain, i))           # large nicotine/water tide stains
        var shade: float = 0.72 + 0.35 * h + 0.12 * (f - 0.5)
        shade *= 1.0 - 0.45 * damp - 0.3 * streak - 0.25 * tide
        shade *= 1.0 - 0.7 * crack
        var r: float = 0.55 * shade
        var g: float = 0.58 * shade * (1.0 + 0.1 * damp)
        var b: float = 0.6 * shade
        # yellowed tide stains, then bare grey concrete where paint peeled off
        r = lerpf(r, r * 1.12, tide)
        b = lerpf(b, b * 0.82, tide)
        r = lerpf(r, 0.30 * (0.7 + 0.5 * f), pl)
        g = lerpf(g, 0.31 * (0.7 + 0.5 * f), pl)
        b = lerpf(b, 0.32 * (0.7 + 0.5 * f), pl)
        alb[i * 3] = _b(r)
        alb[i * 3 + 1] = _b(g)
        alb[i * 3 + 2] = _b(b)
        var hv: float = h * 150.0 + 60.0 + (f - 0.5) * 30.0 - crack * 70.0 - pl * 55.0 + edge * 25.0
        hgt[i] = clampi(int(hv), 0, 255)
        rgh[i] = _b(clampf(0.86 - 0.4 * damp - 0.1 * streak - 0.1 * tide + 0.1 * pl + (f - 0.5) * 0.12, 0.1, 1.0))
    return _pack(alb, hgt, rgh, 2.8, 5, 7.0)


static func _tile(base: Color, wet_floor: bool) -> Dictionary:
    var cell: int = S / 2
    var hn := _noise(21, 0.04, 5)
    var wet := _noise(22, 0.015, 3)
    var dirt := _noise(23, 0.08, 4)
    var fine := _noise(24, 0.4, 2)
    var crk := _noise(25, 0.03, 2)
    var scuff := _streaks(26, false)
    var alb := PackedByteArray()
    alb.resize(S * S * 3)
    var hgt := PackedByteArray()
    hgt.resize(S * S)
    var rgh := PackedByteArray()
    rgh.resize(S * S)
    var rbase: float = 0.55 if wet_floor else 0.9
    var gw: int = maxi(S / 64, 3)
    for y in S:
        for x in S:
            var i: int = y * S + x
            var tx: int = x / cell
            var ty: int = y / cell
            var gx: int = x % cell
            var gy: int = y % cell
            var edge: int = mini(mini(gx, cell - 1 - gx), mini(gy, cell - 1 - gy))
            var grout: float = 1.0 if edge < gw else 0.0
            var bevel: float = 1.0 - smoothstep(float(gw), float(gw) + 5.0, float(edge))   # worn bevel at tile rims
            var tv: float = fposmod(sin(float(tx * 37 + ty * 91 + 3)) * 43758.5453, 1.0)
            var hv: float = _v(hn, i)
            var fv: float = _v(fine, i)
            var dv: float = smoothstep(0.5, 0.9, _v(dirt, i))
            var wv: float = 0.0
            if wet_floor:
                wv = smoothstep(0.5, 0.72, _v(wet, i))
            var cr: float = _ridge(_v(crk, i), 0.01) * (1.0 - grout)
            var sc: float = smoothstep(0.55, 0.9, _v(scuff, i)) * 0.5
            var shade: float = 0.75 + 0.25 * tv + 0.3 * hv + 0.08 * (fv - 0.5)
            shade *= (1.0 - 0.6 * grout) * (1.0 - 0.38 * dv) * (1.0 - 0.4 * wv) * (1.0 - 0.45 * cr) * (1.0 - 0.15 * sc)
            shade *= 1.0 + 0.12 * bevel * (1.0 - dv)
            var tint: float = (tv - 0.5) * 0.06
            alb[i * 3] = _b(base.r * shade * (1.0 + tint))
            alb[i * 3 + 1] = _b(base.g * shade)
            alb[i * 3 + 2] = _b(base.b * shade * (1.0 - tint))
            hgt[i] = clampi(int(150.0 + 50.0 * hv + 15.0 * (fv - 0.5) - 110.0 * grout - 20.0 * dv - 50.0 * cr - 25.0 * bevel), 0, 255)
            rgh[i] = _b(clampf(rbase - 0.5 * wv + 0.4 * grout + 0.12 * dv + 0.15 * sc + 0.2 * cr + (fv - 0.5) * 0.1, 0.04, 1.0))
    return _pack(alb, hgt, rgh, 2.2, 5, 8.0)


static func _metal() -> Dictionary:
    var hn := _noise(41, 0.05, 4)
    var st := _streaks(42, false)
    var rust := _noise(43, 0.02, 4)
    var sc := _noise(44, 0.3, 1)
    var sc2 := _noise(45, 0.22, 1)
    var chip := _noise(46, 0.06, 3)
    var fine := _noise(47, 0.45, 2)
    var alb := PackedByteArray()
    alb.resize(S * S * 3)
    var hgt := PackedByteArray()
    hgt.resize(S * S)
    var rgh := PackedByteArray()
    rgh.resize(S * S)
    for i in S * S:
        var sv: float = _v(st, i)
        var rn: float = _v(rust, i)
        var rv: float = smoothstep(0.58, 0.8, rn)
        var pit: float = smoothstep(0.7, 0.9, _v(chip, i)) * rv
        var scr: float = maxf(_ridge(_v(sc, i), 0.008), _ridge(_v(sc2, i), 0.006) * 0.8)
        var paint: float = 1.0 - smoothstep(0.62, 0.7, _v(chip, i))      # chipped paint exposes bare steel
        var fv: float = _v(fine, i)
        var base: float = 0.33 + 0.12 * sv - 0.05 * _v(hn, i) + 0.25 * scr + 0.03 * (fv - 0.5)
        base = lerpf(base * 1.25, base, paint)
        var rcol := Color(0.42, 0.2, 0.1).lerp(Color(0.3, 0.13, 0.07), fv)
        alb[i * 3] = _b(base * 0.95 * (1.0 - rv) + rcol.r * rv)
        alb[i * 3 + 1] = _b(base * (1.0 - rv) + rcol.g * rv)
        alb[i * 3 + 2] = _b(base * 1.08 * (1.0 - rv) + rcol.b * rv)
        hgt[i] = clampi(int(128.0 + sv * 35.0 - rv * 35.0 - pit * 40.0 - scr * 30.0 + (fv - 0.5) * 20.0 + (1.0 - paint) * -12.0), 0, 255)
        rgh[i] = _b(clampf(0.32 + 0.25 * sv + 0.5 * rv + 0.1 * (fv - 0.5) - 0.12 * scr + (1.0 - paint) * -0.1, 0.1, 1.0))
    return _pack(alb, hgt, rgh, 1.6, 4, 6.0)


static func _wood(crate: bool) -> Dictionary:
    var hn := _noise(51, 0.03, 4)
    var gn := _noise(52, 0.15, 3)
    var knot := _noise(53, 0.025, 2)
    var stain := _noise(54, 0.012, 3)
    var alb := PackedByteArray()
    alb.resize(S * S * 3)
    var hgt := PackedByteArray()
    hgt.resize(S * S)
    var rgh := PackedByteArray()
    rgh.resize(S * S)
    var pw: int = S / 4
    var pl: int = S / 2
    for y in S:
        for x in S:
            var i: int = y * S + x
            var warp: float = _v(hn, i) * 7.5 + _v(knot, i) * 14.0
            var grain: float = 0.5 + 0.5 * sin(float(y) * 0.35 + warp)
            var fibre: float = _v(gn, i)
            var plank: float = 0.0
            var nail: float = 0.0
            if crate:
                if (y % pw) < 3 or (x % pl) < 3:
                    plank = 1.0
                var ny: int = y % pw
                var nx: int = x % pl
                var d1: float = Vector2(float(nx - 12), float(ny - pw / 2)).length()
                var d2: float = Vector2(float(nx - (pl - 12)), float(ny - pw / 2)).length()
                nail = 1.0 if (d1 < 4.0 or d2 < 4.0) else 0.0
            var kn: float = smoothstep(0.78, 0.9, _v(knot, i))
            var st: float = smoothstep(0.55, 0.85, _v(stain, i))
            var base: float = (0.34 + 0.16 * grain + 0.08 * fibre - 0.14 * kn) * (1.0 - 0.7 * plank) * (1.0 - 0.35 * st)
            base = lerpf(base, 0.4, nail * 0.6)
            alb[i * 3] = _b(base)
            alb[i * 3 + 1] = _b(base * 0.72)
            alb[i * 3 + 2] = _b(base * 0.48)
            hgt[i] = clampi(int(120.0 + grain * 45.0 + fibre * 10.0 - plank * 100.0 - kn * 30.0 + nail * 25.0), 0, 255)
            rgh[i] = _b(clampf(0.72 + 0.2 * grain - 0.15 * st - 0.3 * nail, 0.1, 1.0))
    return _pack(alb, hgt, rgh, 1.8, 4, 6.0)


# Pale, mottled, slightly translucent-looking skin for the Watcher: veins, blotches, pores.
static func _skin() -> Dictionary:
    var mott := _noise(61, 0.02, 4)
    var vein := _noise(62, 0.035, 3)
    var pore := _noise(63, 0.5, 2)
    var bruise := _noise(64, 0.012, 3)
    var alb := PackedByteArray()
    alb.resize(S * S * 3)
    var hgt := PackedByteArray()
    hgt.resize(S * S)
    var rgh := PackedByteArray()
    rgh.resize(S * S)
    for i in S * S:
        var m: float = _v(mott, i)
        var vn: float = _ridge(_v(vein, i), 0.035)
        var p: float = _v(pore, i)
        var br: float = smoothstep(0.6, 0.85, _v(bruise, i))
        var r: float = 0.52 + 0.1 * (m - 0.5)
        var g: float = 0.47 + 0.08 * (m - 0.5)
        var b: float = 0.46 + 0.07 * (m - 0.5)
        r = lerpf(r, 0.32, vn * 0.45)
        g = lerpf(g, 0.38, vn * 0.45)
        b = lerpf(b, 0.47, vn * 0.45)
        r = lerpf(r, 0.34, br * 0.6)
        g = lerpf(g, 0.28, br * 0.6)
        b = lerpf(b, 0.36, br * 0.6)
        alb[i * 3] = _b(r)
        alb[i * 3 + 1] = _b(g)
        alb[i * 3 + 2] = _b(b)
        hgt[i] = clampi(int(130.0 + (p - 0.5) * 50.0 + (m - 0.5) * 40.0 + vn * 12.0), 0, 255)
        rgh[i] = _b(clampf(0.5 + 0.15 * (p - 0.5) - 0.12 * vn, 0.2, 0.9))
    return _pack(alb, hgt, rgh, 1.4, 3, 4.0)


# ---------------- decals ----------------

static func get_decal(kind: String) -> ImageTexture:
    if _decals.has(kind):
        return _decals[kind] as ImageTexture
    var w: int = 192
    var h: int = 192
    var n := FastNoiseLite.new()
    n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    n.fractal_type = FastNoiseLite.FRACTAL_FBM
    n.fractal_octaves = 5
    var n2 := FastNoiseLite.new()
    n2.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    n2.fractal_octaves = 3
    n2.seed = 5
    match kind:
        "blotch":
            n.seed = 77
            n.frequency = 0.015
        "streak":
            n.seed = 78
            n.frequency = 0.025
        "crack":
            n.seed = 79
            n.frequency = 0.02
        "damp":
            n.seed = 80
            n.frequency = 0.012
    var img := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
    for y in h:
        for x in w:
            var u: float = float(x) / float(w - 1) * 2.0 - 1.0
            var v: float = float(y) / float(h - 1) * 2.0 - 1.0
            var fx: float = float(x)
            var fy: float = float(y)
            var a: float = 0.0
            var col: Color = Color(0.04, 0.035, 0.03)
            if kind == "blotch":
                var nv: float = n.get_noise_2d(fx, fy) * 0.5 + 0.5
                var rad: float = 1.0 - clampf(sqrt(u * u + v * v), 0.0, 1.0)
                a = smoothstep(0.3, 0.62, nv) * smoothstep(0.0, 0.5, rad)
                var rim: float = smoothstep(0.3, 0.36, nv) * (1.0 - smoothstep(0.36, 0.5, nv))   # darker tide-mark edge
                a = clampf(a + rim * 0.25 * smoothstep(0.0, 0.3, rad), 0.0, 1.0)
                col = Color(0.04, 0.035, 0.03).lerp(Color(0.1, 0.05, 0.03), n2.get_noise_2d(fx, fy) * 0.5 + 0.5)
            elif kind == "streak":
                var nv: float = n.get_noise_2d(fx, fy * 0.1) * 0.5 + 0.5
                var fxm: float = 1.0 - clampf(absf(u), 0.0, 1.0)
                var fym: float = smoothstep(0.0, 0.2, 1.0 - absf(v))
                a = smoothstep(0.4, 0.62, nv) * smoothstep(0.0, 0.6, fxm) * fym
                var drip: float = smoothstep(0.1, 0.0, absf(u - n2.get_noise_2d(fx * 0.5, 0.0) * 0.6)) * smoothstep(-1.0, 0.2, v)
                a = clampf(a + drip * 0.5, 0.0, 1.0)
                col = Color(0.05, 0.07, 0.06).lerp(Color(0.12, 0.07, 0.04), n2.get_noise_2d(fx, fy) * 0.5 + 0.5)
            elif kind == "crack":
                var cv: float = n.get_noise_2d(fx, fy) * 0.5 + 0.5
                var line: float = _ridge(cv, 0.018)
                var fine: float = _ridge(n2.get_noise_2d(fx * 1.7, fy * 1.7) * 0.5 + 0.5, 0.02) * 0.5
                a = clampf(line + fine, 0.0, 1.0) * smoothstep(0.0, 0.35, 1.0 - sqrt(u * u + v * v))
                col = Color(0.02, 0.02, 0.02)
            else:  # damp
                var nv: float = n.get_noise_2d(fx, fy) * 0.5 + 0.5
                var rad: float = 1.0 - clampf(sqrt(u * u + v * v), 0.0, 1.0)
                a = smoothstep(0.35, 0.7, nv) * smoothstep(0.0, 0.6, rad) * 0.7
                col = Color(0.025, 0.03, 0.03)
            col.a = a * 0.85
            img.set_pixel(x, y, col)
    img.generate_mipmaps()
    var tex := ImageTexture.create_from_image(img)
    _decals[kind] = tex
    return tex


# Flashlight beam pattern (used as a SpotLight3D projector): hot centre, soft edge,
# faint concentric lens rings and a slightly dark spot where the bulb sits - like a real torch.
static func get_flashlight_cookie() -> ImageTexture:
    if _cookie != null:
        return _cookie
    var sz: int = 256
    var n := FastNoiseLite.new()
    n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    n.seed = 91
    n.frequency = 0.03
    var img := Image.create_empty(sz, sz, false, Image.FORMAT_RGB8)
    for y in sz:
        for x in sz:
            var u: float = (float(x) / float(sz - 1)) * 2.0 - 1.0
            var v: float = (float(y) / float(sz - 1)) * 2.0 - 1.0
            var r: float = sqrt(u * u + v * v)
            var ang: float = atan2(v, u)
            var core: float = 1.0 - smoothstep(0.0, 0.95, r)
            core = pow(core, 0.8)
            var edge: float = 1.0 - smoothstep(0.82, 1.0, r)
            var rings: float = 1.0 + 0.06 * sin(r * 38.0) + 0.04 * sin(r * 91.0 + 1.0)
            var hot: float = 1.0 - 0.18 * (1.0 - smoothstep(0.0, 0.12, r))        # bulb shadow
            var spokes: float = 1.0 + 0.05 * sin(ang * 14.0 + r * 4.0)
            var warp: float = 1.0 + 0.1 * n.get_noise_2d(float(x), float(y))
            var l: float = clampf((0.35 + 0.65 * core) * edge * rings * hot * spokes * warp, 0.0, 1.0)
            # slightly warm in the centre, cooler at the rim
            img.set_pixel(x, y, Color(l, l * (0.97 - 0.05 * r), l * (0.92 - 0.12 * r)))
    img.generate_mipmaps()
    _cookie = ImageTexture.create_from_image(img)
    return _cookie

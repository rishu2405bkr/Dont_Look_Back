extends StaticBody3D
# Anything the player can press E on. The level sets "prompt" and "on_interact".

var prompt: String = "Interact"
var enabled: bool = true
var on_interact: Callable = Callable()


func get_prompt() -> String:
    if not enabled:
        return ""
    return "[E] " + prompt


func interact(player) -> void:
    if not enabled:
        return
    if on_interact.is_valid():
        on_interact.call(player)

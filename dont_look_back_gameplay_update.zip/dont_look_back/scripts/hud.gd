extends CanvasLayer
# HUD built entirely in code: crosshair, prompt, objective, radio text, bars, notes, fades, ending.

signal restart_requested
signal menu_requested

var prompt_label: Label
var objective_label: Label
var message_label: Label
var crosshair: ColorRect
var stamina_bar: ProgressBar
var battery_bar: ProgressBar
var fade_rect: ColorRect
var note_panel: PanelContainer
var note_title: Label
var note_body: Label
var ending_root: Control
var slot_panels: Array = []
var ending_title: Label
var ending_body: Label

var _root: Control
var _msg_left: float = 0.0


func _ready() -> void:
    layer = 10
    _root = Control.new()
    _root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_root)
    _root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    _build_vignette()
    _build_crosshair()
    _build_text()
    _build_bars()
    _build_note()
    _build_inventory()

    fade_rect = ColorRect.new()
    fade_rect.color = Color(0, 0, 0, 1)
    fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    fade_rect.modulate = Color(1, 1, 1, 0)
    _root.add_child(fade_rect)
    fade_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    _build_ending()


func _process(delta: float) -> void:
    if _msg_left > 0.0:
        _msg_left -= delta
        if _msg_left <= 0.0:
            message_label.text = ""


# ---------- public API ----------

func set_prompt(text: String) -> void:
    prompt_label.text = text


func set_objective(text: String) -> void:
    objective_label.text = "OBJECTIVE: " + text


func show_message(text: String, secs: float = 4.0) -> void:
    message_label.text = text
    _msg_left = secs


func set_bars(stamina_frac: float, battery_frac: float) -> void:
    stamina_bar.value = stamina_frac * 100.0
    battery_bar.value = battery_frac * 100.0


func set_gaze(is_observed: bool) -> void:
    crosshair.color = Color(0.6, 0.85, 1.0, 0.95) if is_observed else Color(1, 1, 1, 0.55)


func set_fragments(count: int) -> void:
    for i in range(1, slot_panels.size()):
        var sb := StyleBoxFlat.new()
        sb.set_border_width_all(2)
        sb.set_corner_radius_all(3)
        if i <= count:
            sb.bg_color = Color(0.25, 0.17, 0.05, 0.9)
            sb.border_color = Color(1.0, 0.8, 0.35, 1.0)
        else:
            sb.bg_color = Color(0.03, 0.03, 0.04, 0.7)
            sb.border_color = Color(0.3, 0.32, 0.36, 0.8)
        slot_panels[i].add_theme_stylebox_override("panel", sb)


func show_note(title: String, body: String) -> void:
    note_title.text = title
    note_body.text = body
    note_panel.visible = true


func hide_note() -> void:
    note_panel.visible = false


func set_black() -> void:
    fade_rect.modulate = Color(1, 1, 1, 1)


func fade(target: float, secs: float) -> Tween:
    var tw := create_tween()
    tw.tween_property(fade_rect, "modulate:a", target, secs)
    return tw


func show_ending(title: String, body: String) -> void:
    ending_title.text = title
    ending_body.text = body
    ending_root.visible = true
    ending_root.modulate = Color(1, 1, 1, 0)
    var tw := create_tween()
    tw.tween_property(ending_root, "modulate:a", 1.0, 2.0)
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


# ---------- builders ----------

func _label(parent: Control, size_px: int, color: Color) -> Label:
    var l := Label.new()
    l.add_theme_font_size_override("font_size", size_px)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
    l.add_theme_constant_override("outline_size", 4)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(l)
    return l


func _band(c: Control, frac: float, height: float) -> void:
    c.anchor_left = 0.0
    c.anchor_right = 1.0
    c.anchor_top = frac
    c.anchor_bottom = frac
    c.offset_left = 30.0
    c.offset_right = -30.0
    c.offset_top = 0.0
    c.offset_bottom = height


func _build_vignette() -> void:
    var grad := Gradient.new()
    grad.set_color(0, Color(0, 0, 0, 0.0))
    grad.set_color(1, Color(0, 0, 0, 0.3))
    grad.set_offset(0, 0.5)
    grad.set_offset(1, 1.0)
    var tex := GradientTexture2D.new()
    tex.gradient = grad
    tex.fill = GradientTexture2D.FILL_RADIAL
    tex.fill_from = Vector2(0.5, 0.5)
    tex.fill_to = Vector2(1.0, 0.5)
    tex.width = 256
    tex.height = 256
    var tr := TextureRect.new()
    tr.texture = tex
    tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    tr.stretch_mode = TextureRect.STRETCH_SCALE
    tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _root.add_child(tr)
    tr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _build_crosshair() -> void:
    crosshair = ColorRect.new()
    crosshair.color = Color(1, 1, 1, 0.55)
    crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _root.add_child(crosshair)
    crosshair.set_anchors_preset(Control.PRESET_CENTER)
    crosshair.offset_left = -2.0
    crosshair.offset_right = 2.0
    crosshair.offset_top = -2.0
    crosshair.offset_bottom = 2.0


func _build_text() -> void:
    prompt_label = _label(_root, 26, Color(0.9, 0.95, 1.0))
    prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _band(prompt_label, 0.58, 40.0)

    message_label = _label(_root, 22, Color(0.6, 0.95, 0.8))
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _band(message_label, 0.72, 90.0)

    objective_label = _label(_root, 18, Color(0.85, 0.88, 0.7))
    objective_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    objective_label.anchor_left = 0.0
    objective_label.anchor_right = 0.0
    objective_label.anchor_top = 0.0
    objective_label.anchor_bottom = 0.0
    objective_label.offset_left = 28.0
    objective_label.offset_top = 22.0
    objective_label.offset_right = 560.0
    objective_label.offset_bottom = 100.0


func _build_bars() -> void:
    stamina_bar = _make_bar("STAMINA", -64.0, Color(0.8, 0.8, 0.6))
    battery_bar = _make_bar("BATTERY", -38.0, Color(0.5, 0.8, 1.0))


func _make_bar(text: String, y: float, color: Color) -> ProgressBar:
    var l := _label(_root, 13, Color(0.75, 0.78, 0.82))
    l.text = text
    l.anchor_left = 0.0
    l.anchor_right = 0.0
    l.anchor_top = 1.0
    l.anchor_bottom = 1.0
    l.offset_left = 28.0
    l.offset_right = 100.0
    l.offset_top = y - 4.0
    l.offset_bottom = y + 14.0
    var b := ProgressBar.new()
    b.min_value = 0.0
    b.max_value = 100.0
    b.value = 100.0
    b.show_percentage = false
    b.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var fill := StyleBoxFlat.new()
    fill.bg_color = color
    b.add_theme_stylebox_override("fill", fill)
    var bg := StyleBoxFlat.new()
    bg.bg_color = Color(0, 0, 0, 0.55)
    b.add_theme_stylebox_override("background", bg)
    _root.add_child(b)
    b.anchor_left = 0.0
    b.anchor_right = 0.0
    b.anchor_top = 1.0
    b.anchor_bottom = 1.0
    b.offset_left = 104.0
    b.offset_right = 284.0
    b.offset_top = y
    b.offset_bottom = y + 10.0
    return b


func _build_inventory() -> void:
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 8)
    hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _root.add_child(hb)
    hb.anchor_left = 0.5
    hb.anchor_right = 0.5
    hb.anchor_top = 1.0
    hb.anchor_bottom = 1.0
    hb.offset_left = -140.0
    hb.offset_right = 140.0
    hb.offset_top = -86.0
    hb.offset_bottom = -22.0
    var names: Array = ["LIGHT", "FRAG 1", "FRAG 2", "FRAG 3"]
    for i in 4:
        var p := PanelContainer.new()
        p.custom_minimum_size = Vector2(64, 64)
        p.mouse_filter = Control.MOUSE_FILTER_IGNORE
        var l := Label.new()
        l.text = String(names[i])
        l.add_theme_font_size_override("font_size", 12)
        l.add_theme_color_override("font_color", Color(0.8, 0.82, 0.86))
        l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        p.add_child(l)
        hb.add_child(p)
        slot_panels.append(p)
    var first := StyleBoxFlat.new()
    first.bg_color = Color(0.05, 0.06, 0.08, 0.85)
    first.border_color = Color(0.9, 0.9, 0.95, 0.9)
    first.set_border_width_all(2)
    first.set_corner_radius_all(3)
    slot_panels[0].add_theme_stylebox_override("panel", first)
    set_fragments(0)


func _build_note() -> void:
    note_panel = PanelContainer.new()
    note_panel.visible = false
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.74, 0.69, 0.57, 0.98)
    sb.border_color = Color(0.3, 0.25, 0.18, 0.9)
    sb.set_border_width_all(2)
    sb.set_content_margin_all(24)
    note_panel.add_theme_stylebox_override("panel", sb)
    _root.add_child(note_panel)
    note_panel.set_anchors_preset(Control.PRESET_CENTER)
    note_panel.offset_left = -340.0
    note_panel.offset_right = 340.0
    note_panel.offset_top = -230.0
    note_panel.offset_bottom = 230.0
    note_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
    note_panel.grow_vertical = Control.GROW_DIRECTION_BOTH

    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 10)
    note_panel.add_child(vb)

    note_title = Label.new()
    note_title.add_theme_font_size_override("font_size", 22)
    note_title.add_theme_color_override("font_color", Color(0.35, 0.08, 0.06))
    vb.add_child(note_title)
    vb.add_child(HSeparator.new())

    note_body = Label.new()
    note_body.add_theme_font_size_override("font_size", 17)
    note_body.add_theme_color_override("font_color", Color(0.14, 0.11, 0.09))
    note_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    note_body.custom_minimum_size = Vector2(620, 0)
    vb.add_child(note_body)

    var hint := Label.new()
    hint.text = "[E] / [Esc] / Click to close"
    hint.add_theme_font_size_override("font_size", 14)
    hint.add_theme_color_override("font_color", Color(0.35, 0.3, 0.25))
    vb.add_child(hint)


func _build_ending() -> void:
    ending_root = Control.new()
    ending_root.visible = false
    _root.add_child(ending_root)
    ending_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var bg := ColorRect.new()
    bg.color = Color(0, 0, 0, 1)
    ending_root.add_child(bg)
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var center := CenterContainer.new()
    ending_root.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 18)
    center.add_child(vb)

    ending_title = Label.new()
    ending_title.add_theme_font_size_override("font_size", 52)
    ending_title.add_theme_color_override("font_color", Color(0.75, 0.88, 1.0))
    ending_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(ending_title)

    ending_body = Label.new()
    ending_body.add_theme_font_size_override("font_size", 19)
    ending_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    ending_body.custom_minimum_size = Vector2(760, 0)
    ending_body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(ending_body)

    var hb := HBoxContainer.new()
    hb.alignment = BoxContainer.ALIGNMENT_CENTER
    hb.add_theme_constant_override("separation", 20)
    vb.add_child(hb)

    var again := Button.new()
    again.text = "PLAY AGAIN"
    again.custom_minimum_size = Vector2(200, 44)
    again.pressed.connect(_on_again)
    hb.add_child(again)

    var menu := Button.new()
    menu.text = "MAIN MENU"
    menu.custom_minimum_size = Vector2(200, 44)
    menu.pressed.connect(_on_menu)
    hb.add_child(menu)


func _on_again() -> void:
    restart_requested.emit()


func _on_menu() -> void:
    menu_requested.emit()

extends CanvasLayer
# Full-screen camera/film look: lens distortion, chromatic aberration, sharpening, halation
# around bright lights, split-toned grade, shadow-weighted sensor grain, dithering, vignette.

const CODE: String = """
shader_type canvas_item;
uniform sampler2D screen_tex : hint_screen_texture, repeat_disable, filter_linear_mipmap;
uniform float grain = 0.05;
uniform float aberration = 0.0018;
uniform float vignette = 0.55;
uniform float distortion = 0.035;
uniform float halation = 0.2;
uniform float sharpen = 0.3;
uniform float stress = 0.0;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float luma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

void fragment() {
    vec2 d0 = SCREEN_UV - vec2(0.5);
    float r2_0 = dot(d0, d0);
    vec2 uv = vec2(0.5) + d0 * (1.0 - distortion * 0.25 + distortion * r2_0);

    vec2 d = uv - vec2(0.5);
    float r2 = dot(d, d);
    vec2 off = d * aberration * (1.0 + r2 * 8.0 + stress * 1.5);
    vec3 col;
    col.r = texture(screen_tex, uv + off).r;
    col.g = texture(screen_tex, uv).g;
    col.b = texture(screen_tex, uv - off).b;

    // gentle unsharp mask (lenses are sharper than a raw render)
    vec2 px = vec2(1.0) / vec2(textureSize(screen_tex, 0));
    vec3 blur = (texture(screen_tex, uv + vec2(px.x, 0.0)).rgb + texture(screen_tex, uv - vec2(px.x, 0.0)).rgb
               + texture(screen_tex, uv + vec2(0.0, px.y)).rgb + texture(screen_tex, uv - vec2(0.0, px.y)).rgb) * 0.25;
    col += (col - blur) * sharpen;

    // halation: warm bleed around bright lights, like film / a real lens
    vec3 soft = textureLod(screen_tex, uv, 4.0).rgb;
    vec3 wide = textureLod(screen_tex, uv, 6.0).rgb;
    float hl = max(luma(soft) - 0.28, 0.0);
    col += halation * vec3(1.0, 0.5, 0.35) * hl * 1.6;
    col += wide * 0.06;

    // grade: cool shadows, warm highlights, slight desaturation, soft S-curve
    float l = luma(col);
    col = mix(vec3(l), col, 0.9);
    col = mix(col, col * vec3(0.9, 1.02, 1.1), 1.0 - smoothstep(0.0, 0.45, l));
    col = mix(col, col * vec3(1.06, 1.0, 0.93), smoothstep(0.45, 1.0, l));
    vec3 sc = clamp(col, 0.0, 1.0);
    col = mix(col, sc * sc * (3.0 - 2.0 * sc), 0.22);

    // sensor noise: stronger in the dark, with a little colour noise
    vec2 fc = FRAGCOORD.xy;
    float t = fract(TIME) * 61.0;
    float n1 = hash12(fc + vec2(t, t * 1.7)) + hash12(fc * 1.3 + vec2(t * 0.6, 3.1)) - 1.0;
    vec3 cn = vec3(hash12(fc + vec2(11.0, t)), hash12(fc + vec2(23.0, t)), hash12(fc + vec2(37.0, t))) - 0.5;
    float amp = grain * (1.35 - clamp(luma(col) * 1.5, 0.0, 1.0));
    col += n1 * amp + cn * amp * 0.35;

    // vignette (tightens when the player is in danger)
    float v = vignette + stress * 0.25;
    col *= 1.0 - v * smoothstep(0.2, 0.85, length(d) * 1.25);

    // dither to remove banding in dark gradients
    col += (hash12(fc + 5.0) - 0.5) / 255.0;
    COLOR = vec4(clamp(col, 0.0, 1.0), 1.0);
}
"""

var _mat: ShaderMaterial = null


func _ready() -> void:
    layer = 5
    var rect := ColorRect.new()
    rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var sh := Shader.new()
    sh.code = CODE
    _mat = ShaderMaterial.new()
    _mat.shader = sh
    rect.material = _mat
    add_child(rect)
    rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


# 0 = calm, 1 = maximum danger (more fringing, tighter vignette)
func set_stress(v: float) -> void:
    if _mat != null:
        _mat.set_shader_parameter("stress", clampf(v, 0.0, 1.0))

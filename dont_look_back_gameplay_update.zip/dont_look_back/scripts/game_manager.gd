extends Node
# Autoload "GameManager": input actions, settings, shared run state.

signal settings_changed
signal fragments_changed(count: int)

const SETTINGS_PATH: String = "user://dont_look_back_settings.cfg"

var sensitivity_ui: float = 4.0
var master_volume: float = 0.8
var reduce_audio: bool = false
var disable_shake: bool = false
var low_spec: bool = false

var fragments: int = 0
var power_restored: bool = false
var times_caught: int = 0
var longest_gaze: float = 0.0
var note_open: bool = false
var notes_read: int = 0
var can_pause: bool = true


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _register_inputs()
    load_settings()
    apply_audio()


func _register_inputs() -> void:
    _add_key("move_forward", KEY_W)
    _add_key("move_forward", KEY_UP)
    _add_key("move_back", KEY_S)
    _add_key("move_back", KEY_DOWN)
    _add_key("move_left", KEY_A)
    _add_key("move_left", KEY_LEFT)
    _add_key("move_right", KEY_D)
    _add_key("move_right", KEY_RIGHT)
    _add_key("sprint", KEY_SHIFT)
    _add_key("crouch", KEY_CTRL)
    _add_key("interact", KEY_E)
    _add_key("flashlight", KEY_F)


func _add_key(action: String, keycode: Key) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action)
    var ev := InputEventKey.new()
    ev.physical_keycode = keycode
    InputMap.action_add_event(action, ev)


func reset_run() -> void:
    fragments = 0
    power_restored = false
    times_caught = 0
    longest_gaze = 0.0
    note_open = false
    notes_read = 0
    can_pause = true


func add_fragment() -> void:
    fragments += 1
    fragments_changed.emit(fragments)


func get_mouse_sensitivity() -> float:
    return 0.0006 * sensitivity_ui


func audio_offset() -> float:
    return -10.0 if reduce_audio else 0.0


func apply_audio() -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(master_volume, 0.001)))


func commit_settings() -> void:
    apply_audio()
    save_settings()
    settings_changed.emit()


func save_settings() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("s", "sens", sensitivity_ui)
    cfg.set_value("s", "vol", master_volume)
    cfg.set_value("s", "reduce_audio", reduce_audio)
    cfg.set_value("s", "no_shake", disable_shake)
    cfg.set_value("s", "low_spec", low_spec)
    cfg.save(SETTINGS_PATH)


func load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SETTINGS_PATH) != OK:
        return
    sensitivity_ui = float(cfg.get_value("s", "sens", sensitivity_ui))
    master_volume = float(cfg.get_value("s", "vol", master_volume))
    reduce_audio = bool(cfg.get_value("s", "reduce_audio", reduce_audio))
    disable_shake = bool(cfg.get_value("s", "no_shake", disable_shake))
    low_spec = bool(cfg.get_value("s", "low_spec", low_spec))

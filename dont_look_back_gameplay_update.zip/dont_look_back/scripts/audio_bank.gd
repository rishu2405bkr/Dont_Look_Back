extends RefCounted
# Procedurally generated sound effects. No audio files are needed or used.
# Usage: AudioBank.get_sound("footstep"), AudioBank.play_at(...), AudioBank.play_ui(...)

const RATE: int = 22050
static var _cache: Dictionary = {}


static func get_sound(id: String) -> AudioStreamWAV:
    if _cache.has(id):
        return _cache[id] as AudioStreamWAV
    var s: AudioStreamWAV
    match id:
        "footstep": s = _footstep()
        "knock": s = _knock()
        "static": s = _static_burst()
        "drone": s = _drone()
        "heartbeat": s = _heartbeat()
        "pickup": s = _pickup()
        "door": s = _door()
        "locked": s = _locked()
        "power": s = _power()
        "caught": s = _caught()
        "buzz": s = _buzz()
        "click": s = _click()
        "paper": s = _paper()
        _: s = _make(PackedFloat32Array([0.0]))
    _cache[id] = s
    return s


static func play_at(parent: Node, id: String, pos: Vector3, db: float = 0.0, pitch: float = 1.0) -> void:
    var p := AudioStreamPlayer3D.new()
    p.stream = get_sound(id)
    p.volume_db = db + GameManager.audio_offset()
    p.pitch_scale = pitch
    p.unit_size = 8.0
    p.max_distance = 70.0
    parent.add_child(p)
    p.global_position = pos
    p.finished.connect(p.queue_free)
    p.play()


static func play_ui(parent: Node, id: String, db: float = 0.0) -> void:
    var p := AudioStreamPlayer.new()
    p.stream = get_sound(id)
    p.volume_db = db + GameManager.audio_offset()
    parent.add_child(p)
    p.finished.connect(p.queue_free)
    p.play()


static func _make(samples: PackedFloat32Array, loop: bool = false) -> AudioStreamWAV:
    var bytes := PackedByteArray()
    bytes.resize(samples.size() * 2)
    for i in samples.size():
        var v: int = int(clampf(samples[i], -1.0, 1.0) * 32000.0)
        bytes.encode_s16(i * 2, v)
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = RATE
    w.stereo = false
    w.data = bytes
    if loop:
        w.loop_mode = AudioStreamWAV.LOOP_FORWARD
        w.loop_begin = 0
        w.loop_end = samples.size()
    return w


static func _footstep() -> AudioStreamWAV:
    var n: int = int(RATE * 0.3)
    var out := PackedFloat32Array()
    out.resize(n)
    var rng := RandomNumberGenerator.new()
    rng.seed = 11
    var lp: float = 0.0
    for i in n:
        var t: float = float(i) / RATE
        var env: float = exp(-t * 16.0)
        lp += 0.15 * (rng.randf_range(-1.0, 1.0) - lp)
        out[i] = (lp * 1.4 + sin(TAU * 58.0 * t) * 0.9) * env * 0.7
    return _make(out)


static func _knock() -> AudioStreamWAV:
    var n: int = int(RATE * 0.9)
    var out := PackedFloat32Array()
    out.resize(n)
    var rng := RandomNumberGenerator.new()
    rng.seed = 21
    for i in n:
        var t: float = float(i) / RATE
        var v: float = 0.0
        for start in [0.0, 0.27, 0.54]:
            var tt: float = t - float(start)
            if tt >= 0.0:
                v += sin(TAU * 140.0 * tt) * exp(-tt * 26.0)
                v += rng.randf_range(-1.0, 1.0) * exp(-tt * 70.0) * 0.35
        out[i] = v * 0.7
    return _make(out)


static func _static_burst() -> AudioStreamWAV:
    var n: int = int(RATE * 1.4)
    var out := PackedFloat32Array()
    out.resize(n)
    var rng := RandomNumberGenerator.new()
    rng.seed = 5
    var prev: float = 0.0
    for i in n:
        var t: float = float(i) / RATE
        var x: float = rng.randf_range(-1.0, 1.0)
        var hp: float = x - prev * 0.5
        prev = x
        var gate: float = 0.55 + 0.45 * sin(TAU * 9.0 * t + sin(TAU * 2.0 * t) * 3.0)
        var env: float = minf(t / 0.05, 1.0) * minf((1.4 - t) / 0.08, 1.0)
        out[i] = hp * gate * env * 0.45
    return _make(out)


static func _drone() -> AudioStreamWAV:
    # 4 seconds, every frequency has a whole number of cycles so it loops cleanly.
    var n: int = RATE * 4
    var out := PackedFloat32Array()
    out.resize(n)
    for i in n:
        var t: float = float(i) / RATE
        var v: float = 0.35 * sin(TAU * 55.0 * t)
        v += 0.25 * sin(TAU * 55.25 * t)
        v += 0.18 * sin(TAU * 82.5 * t)
        v += 0.10 * sin(TAU * 110.25 * t)
        v += 0.05 * sin(TAU * 164.0 * t)
        var trem: float = 0.75 + 0.25 * sin(TAU * 0.5 * t)
        out[i] = v * trem * 0.5
    return _make(out, true)


static func _heartbeat() -> AudioStreamWAV:
    var n: int = RATE
    var out := PackedFloat32Array()
    out.resize(n)
    for i in n:
        var t: float = float(i) / RATE
        var v: float = sin(TAU * 52.0 * t) * exp(-t * 20.0)
        var t2: float = t - 0.3
        if t2 >= 0.0:
            v += 0.7 * sin(TAU * 46.0 * t2) * exp(-t2 * 20.0)
        out[i] = v * 0.9
    return _make(out, true)


static func _pickup() -> AudioStreamWAV:
    var n: int = int(RATE * 0.7)
    var out := PackedFloat32Array()
    out.resize(n)
    for i in n:
        var t: float = float(i) / RATE
        var v: float = 0.5 * sin(TAU * 660.0 * t) * exp(-t * 5.0)
        var t2: float = t - 0.08
        if t2 >= 0.0:
            v += 0.4 * sin(TAU * 990.0 * t2) * exp(-t2 * 5.0)
        out[i] = v * 0.7
    return _make(out)


static func _door() -> AudioStreamWAV:
    var n: int = int(RATE * 1.2)
    var out := PackedFloat32Array()
    out.resize(n)
    var rng := RandomNumberGenerator.new()
    rng.seed = 3
    var lp: float = 0.0
    for i in n:
        var t: float = float(i) / RATE
        var bump: float = sin(PI * t / 1.2)
        lp += 0.08 * (rng.randf_range(-1.0, 1.0) - lp)
        var v: float = lp * 1.8 + sin(TAU * (60.0 + 20.0 * t) * t) * 0.5
        out[i] = v * bump * 0.6
    return _make(out)


static func _locked() -> AudioStreamWAV:
    var n: int = int(RATE * 0.35)
    var out := PackedFloat32Array()
    out.resize(n)
    for i in n:
        var t: float = float(i) / RATE
        var on: bool = t < 0.12 or (t > 0.18 and t < 0.30)
        var v: float = 0.0
        if on:
            v = signf(sin(TAU * 110.0 * t)) * 0.3
        out[i] = v
    return _make(out)


static func _power() -> AudioStreamWAV:
    var n: int = int(RATE * 2.4)
    var out := PackedFloat32Array()
    out.resize(n)
    var phase: float = 0.0
    for i in n:
        var t: float = float(i) / RATE
        var k: float = t / 2.4
        phase += TAU * (40.0 + 90.0 * k * k) / RATE
        var env: float = minf(t / 0.4, 1.0) * minf((2.4 - t) / 0.6, 1.0)
        var v: float = sin(phase) * env * 0.6
        v += sin(TAU * 45.0 * t) * exp(-t * 6.0) * 0.8
        out[i] = v
    return _make(out)


static func _caught() -> AudioStreamWAV:
    var n: int = int(RATE * 1.2)
    var out := PackedFloat32Array()
    out.resize(n)
    var rng := RandomNumberGenerator.new()
    rng.seed = 9
    for i in n:
        var t: float = float(i) / RATE
        var v: float = sin(TAU * 42.0 * t) * exp(-t * 3.0) * 0.9
        v += rng.randf_range(-1.0, 1.0) * exp(-t * 9.0) * 0.5
        out[i] = v * 0.8
    return _make(out)


static func _buzz() -> AudioStreamWAV:
    var n: int = int(RATE * 0.3)
    var out := PackedFloat32Array()
    out.resize(n)
    for i in n:
        var t: float = float(i) / RATE
        out[i] = (fposmod(t * 100.0, 1.0) * 2.0 - 1.0) * exp(-t * 10.0) * 0.5
    return _make(out)


static func _click() -> AudioStreamWAV:
    var n: int = int(RATE * 0.06)
    var out := PackedFloat32Array()
    out.resize(n)
    var rng := RandomNumberGenerator.new()
    rng.seed = 2
    for i in n:
        var t: float = float(i) / RATE
        out[i] = rng.randf_range(-1.0, 1.0) * exp(-t * 80.0) * 0.6
    return _make(out)


static func _paper() -> AudioStreamWAV:
    var n: int = int(RATE * 0.25)
    var out := PackedFloat32Array()
    out.resize(n)
    var rng := RandomNumberGenerator.new()
    rng.seed = 4
    var lp: float = 0.0
    for i in n:
        var t: float = float(i) / RATE
        lp += 0.3 * (rng.randf_range(-1.0, 1.0) - lp)
        out[i] = lp * sin(PI * t / 0.25) * 0.5
    return _make(out)

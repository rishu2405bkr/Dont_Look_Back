extends VBoxContainer
# Shared settings UI used by the main menu and the pause menu.


func _ready() -> void:
    add_theme_constant_override("separation", 8)
    _add_slider("Mouse sensitivity", 1.0, 10.0, 0.1, GameManager.sensitivity_ui, _on_sens)
    _add_slider("Master volume", 0.0, 1.0, 0.05, GameManager.master_volume, _on_volume)
    _add_check("Reduce sudden audio intensity", GameManager.reduce_audio, _on_reduce)
    _add_check("Disable screen shake", GameManager.disable_shake, _on_shake)
    _add_check("Low-spec visuals (no volumetric fog / glow)", GameManager.low_spec, _on_low)


func _add_slider(title: String, min_v: float, max_v: float, step_v: float, value: float, cb: Callable) -> void:
    var l := Label.new()
    l.text = title
    add_child(l)
    var s := HSlider.new()
    s.min_value = min_v
    s.max_value = max_v
    s.step = step_v
    s.value = value
    s.custom_minimum_size = Vector2(320, 24)
    s.value_changed.connect(cb)
    add_child(s)


func _add_check(title: String, value: bool, cb: Callable) -> void:
    var c := CheckBox.new()
    c.text = title
    c.button_pressed = value
    c.toggled.connect(cb)
    add_child(c)


func _on_sens(v: float) -> void:
    GameManager.sensitivity_ui = v
    GameManager.commit_settings()


func _on_volume(v: float) -> void:
    GameManager.master_volume = v
    GameManager.commit_settings()


func _on_reduce(v: bool) -> void:
    GameManager.reduce_audio = v
    GameManager.commit_settings()


func _on_shake(v: bool) -> void:
    GameManager.disable_shake = v
    GameManager.commit_settings()


func _on_low(v: bool) -> void:
    GameManager.low_spec = v
    GameManager.commit_settings()

extends Control
# Main menu. Keep the interface readable and let the atmosphere do the work.
# All UI is created here so the project is easy for a student developer to edit.

const AudioBank = preload("res://scripts/audio_bank.gd")
const SettingsPanel = preload("res://scripts/settings_panel.gd")
const TexGen = preload("res://scripts/tex_gen.gd")

var title_label: Label
var settings_box: VBoxContainer
var start_button: Button
var _elapsed := 0.0
var _status_label: Label

func _ready() -> void:
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    get_tree().paused = false
    _build_background()
    _build_interface()
    _start_ambience()

    # Generate procedural materials before entering the level. The start button
    # remains disabled during setup so players cannot enter a half-built scene.
    _status_label.text = "INITIALISING FACILITY..."
    start_button.disabled = true
    await get_tree().process_frame
    await get_tree().process_frame
    TexGen.build_all()
    _status_label.text = "SYSTEM READY  /  BUILD 01"
    start_button.disabled = false
    start_button.grab_focus()

func _build_background() -> void:
    var bg := ColorRect.new()
    bg.color = Color("080b10")
    add_child(bg)
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    # Restrained side lighting gives the menu depth without hiding the text.
    var left_glow := ColorRect.new()
    left_glow.color = Color(0.20, 0.025, 0.035, 0.24)
    left_glow.position = Vector2(0, 0)
    left_glow.size = Vector2(460, 720)
    add_child(left_glow)
    left_glow.set_anchors_and_offsets_preset(Control.PRESET_LEFT_WIDE)
    left_glow.anchor_right = 0.43
    left_glow.offset_right = 0

    var top_line := ColorRect.new()
    top_line.color = Color(0.65, 0.12, 0.12, 0.8)
    top_line.anchor_right = 1.0
    top_line.offset_bottom = 2
    add_child(top_line)

    var footer := Label.new()
    footer.text = "FIELD RECORDING  //  SITE 09  //  DO NOT TURN AROUND"
    footer.add_theme_font_size_override("font_size", 11)
    footer.add_theme_color_override("font_color", Color(0.43, 0.47, 0.52))
    footer.anchor_left = 0.035
    footer.anchor_top = 0.94
    footer.anchor_right = 0.75
    footer.anchor_bottom = 0.99
    add_child(footer)

func _build_interface() -> void:
    var center := CenterContainer.new()
    add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(560, 0)
    var panel_style := StyleBoxFlat.new()
    panel_style.bg_color = Color(0.035, 0.045, 0.06, 0.94)
    panel_style.border_color = Color(0.28, 0.10, 0.12, 0.95)
    panel_style.set_border_width_all(1)
    panel_style.set_content_margin_all(30)
    panel_style.corner_radius_top_left = 4
    panel_style.corner_radius_top_right = 4
    panel_style.corner_radius_bottom_left = 4
    panel_style.corner_radius_bottom_right = 4
    panel.add_theme_stylebox_override("panel", panel_style)
    center.add_child(panel)

    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 13)
    panel.add_child(vb)

    var eyebrow := Label.new()
    eyebrow.text = "A FIRST-PERSON PSYCHOLOGICAL HORROR EXPERIENCE"
    eyebrow.add_theme_font_size_override("font_size", 10)
    eyebrow.add_theme_color_override("font_color", Color("b65b60"))
    eyebrow.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(eyebrow)

    title_label = Label.new()
    title_label.text = "DON'T LOOK\nBACK"
    title_label.add_theme_font_size_override("font_size", 58)
    title_label.add_theme_color_override("font_color", Color("e4e7e9"))
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(title_label)

    var sub := Label.new()
    sub.text = "IT ONLY MOVES WHEN YOU LOOK AWAY."
    sub.add_theme_font_size_override("font_size", 13)
    sub.add_theme_color_override("font_color", Color("9da5ae"))
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(sub)

    var divider := ColorRect.new()
    divider.color = Color(0.35, 0.12, 0.14, 0.9)
    divider.custom_minimum_size = Vector2(0, 1)
    vb.add_child(divider)

    var start_row := HBoxContainer.new()
    start_row.alignment = BoxContainer.ALIGNMENT_CENTER
    vb.add_child(start_row)
    start_button = _button(start_row, "ENTER FACILITY", _on_start, true)

    var row := HBoxContainer.new()
    row.alignment = BoxContainer.ALIGNMENT_CENTER
    row.add_theme_constant_override("separation", 10)
    vb.add_child(row)
    _button(row, "SETTINGS", _toggle_settings, false)
    _button(row, "QUIT", _on_quit, false)

    settings_box = SettingsPanel.new()
    settings_box.visible = false
    settings_box.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    vb.add_child(settings_box)

    var controls := Label.new()
    controls.text = "WASD MOVE   ·   MOUSE LOOK   ·   SHIFT RUN   ·   CTRL CROUCH\nF FLASHLIGHT   ·   E INTERACT   ·   ESC PAUSE"
    controls.add_theme_font_size_override("font_size", 11)
    controls.add_theme_color_override("font_color", Color("77818b"))
    controls.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(controls)

    _status_label = Label.new()
    _status_label.text = ""
    _status_label.add_theme_font_size_override("font_size", 10)
    _status_label.add_theme_color_override("font_color", Color("8c555a"))
    _status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(_status_label)

func _button(parent: Control, label_text: String, callback: Callable, primary: bool) -> Button:
    var b := Button.new()
    b.text = label_text
    b.custom_minimum_size = Vector2(220 if primary else 145, 44)
    b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    b.focus_mode = Control.FOCUS_ALL
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.29, 0.055, 0.07, 0.95) if primary else Color(0.075, 0.09, 0.115, 0.96)
    normal.border_color = Color(0.56, 0.15, 0.18) if primary else Color(0.20, 0.24, 0.29)
    normal.set_border_width_all(1)
    normal.set_content_margin_all(10)
    var hover := normal.duplicate() as StyleBoxFlat
    hover.bg_color = Color(0.43, 0.075, 0.09) if primary else Color(0.13, 0.15, 0.18)
    hover.border_color = Color(0.82, 0.24, 0.26)
    var pressed := hover.duplicate() as StyleBoxFlat
    pressed.bg_color = Color(0.18, 0.035, 0.045)
    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("hover", hover)
    b.add_theme_stylebox_override("pressed", pressed)
    b.add_theme_stylebox_override("focus", hover)
    b.add_theme_color_override("font_color", Color("e4e7e9"))
    b.add_theme_color_override("font_hover_color", Color("ffffff"))
    b.add_theme_font_size_override("font_size", 12)
    b.pressed.connect(callback)
    parent.add_child(b)
    return b

func _start_ambience() -> void:
    var drone := AudioStreamPlayer.new()
    drone.stream = AudioBank.get_sound("drone")
    drone.volume_db = -24.0 + GameManager.audio_offset()
    add_child(drone)
    drone.play()

func _process(delta: float) -> void:
    _elapsed += delta
    if is_instance_valid(title_label):
        var pulse := 0.94 + 0.06 * sin(_elapsed * 1.35)
        title_label.modulate = Color(pulse, pulse, pulse, 1.0)

func _on_start() -> void:
    get_tree().change_scene_to_file("res://scenes/main_game.tscn")

func _toggle_settings() -> void:
    settings_box.visible = not settings_box.visible

func _on_quit() -> void:
    get_tree().quit()

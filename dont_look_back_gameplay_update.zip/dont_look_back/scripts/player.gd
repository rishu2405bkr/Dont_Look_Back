extends CharacterBody3D
# First-person player. Every node is created in code, so no scene setup is needed.

const AudioBank = preload("res://scripts/audio_bank.gd")
const TexGen = preload("res://scripts/tex_gen.gd")

signal prompt_changed(text: String)

var walk_speed: float = 3.5
var sprint_speed: float = 6.0
var crouch_speed: float = 1.8
var acceleration: float = 14.0

var max_stamina: float = 100.0
var stamina: float = 100.0
var stamina_drain: float = 25.0
var stamina_regen: float = 14.0
var regen_delay: float = 1.0
var exhausted_recover_at: float = 25.0
var exhausted: bool = false

var max_battery: float = 100.0
var battery: float = 100.0
var battery_drain: float = 1.5
var battery_recharge: float = 4.0
var battery_min_to_turn_on: float = 10.0

var stand_head_height: float = 1.6
var crouch_head_height: float = 1.0

var frozen: bool = false
var is_crouching: bool = false

var head: Node3D
var camera: Camera3D
var flashlight: SpotLight3D
var interact_ray: RayCast3D

var _regen_timer: float = 0.0
var _last_prompt: String = ""
var _flash_energy: float = 3.0
var _step_timer: float = 0.0
var _step_audio: AudioStreamPlayer
var _shake: float = 0.0
var _lens_mat: StandardMaterial3D
var _dust: GPUParticles3D
var _spill: SpotLight3D
var _holder: Node3D
var _bob_t: float = 0.0
var _bob_amp: float = 0.0
var _breath_t: float = 0.0
var _sway: Vector2 = Vector2.ZERO
var _sway_target: Vector2 = Vector2.ZERO
var _sprinting: bool = false


func _ready() -> void:
    stamina = max_stamina
    battery = max_battery

    var col := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.35
    cap.height = 1.7
    col.shape = cap
    col.position = Vector3(0.0, 0.85, 0.0)
    add_child(col)

    head = Node3D.new()
    head.position = Vector3(0.0, stand_head_height, 0.0)
    add_child(head)

    camera = Camera3D.new()
    camera.fov = 75.0
    camera.near = 0.05
    camera.far = 90.0
    head.add_child(camera)
    camera.current = true

    flashlight = SpotLight3D.new()
    flashlight.light_energy = _flash_energy
    flashlight.spot_range = 22.0
    flashlight.spot_angle = 32.0
    flashlight.spot_attenuation = 0.8
    flashlight.shadow_enabled = true
    flashlight.light_volumetric_fog_energy = 2.0
    flashlight.light_color = Color(1.0, 0.96, 0.88)
    flashlight.light_projector = TexGen.get_flashlight_cookie()
    flashlight.shadow_blur = 1.5
    flashlight.visible = false
    head.add_child(flashlight)

    # wide, weak spill around the main beam (real torches leak light past the hot spot)
    _spill = SpotLight3D.new()
    _spill.light_energy = 0.35
    _spill.spot_range = 9.0
    _spill.spot_angle = 68.0
    _spill.spot_attenuation = 1.2
    _spill.light_color = Color(0.85, 0.9, 1.0)
    _spill.shadow_enabled = false
    _spill.visible = false
    head.add_child(_spill)

    _build_viewmodel()
    _build_dust()
    GameManager.settings_changed.connect(_on_settings_changed)

    interact_ray = RayCast3D.new()
    interact_ray.target_position = Vector3(0.0, 0.0, -2.6)
    interact_ray.collision_mask = 1
    interact_ray.enabled = true
    head.add_child(interact_ray)
    interact_ray.add_exception(self)

    _step_audio = AudioStreamPlayer.new()
    _step_audio.stream = AudioBank.get_sound("footstep")
    _step_audio.volume_db = -14.0
    add_child(_step_audio)


func _build_dust() -> void:
    # Faint floating dust that catches the light.
    _dust = GPUParticles3D.new()
    _dust.amount = 90
    _dust.lifetime = 12.0
    _dust.preprocess = 12.0
    _dust.local_coords = false
    _dust.visibility_aabb = AABB(Vector3(-8.0, -4.0, -8.0), Vector3(16.0, 8.0, 16.0))
    _dust.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    var pm := ParticleProcessMaterial.new()
    pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
    pm.emission_box_extents = Vector3(6.0, 1.5, 6.0)
    pm.direction = Vector3(0.0, 1.0, 0.0)
    pm.spread = 180.0
    pm.initial_velocity_min = 0.02
    pm.initial_velocity_max = 0.08
    pm.gravity = Vector3(0.0, -0.01, 0.0)
    _dust.process_material = pm
    var qm := QuadMesh.new()
    qm.size = Vector2(0.012, 0.012)
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.albedo_color = Color(0.8, 0.85, 0.9, 0.35)
    qm.material = mat
    _dust.draw_pass_1 = qm
    _dust.visible = not GameManager.low_spec
    head.add_child(_dust)


func _on_settings_changed() -> void:
    if _dust != null:
        _dust.visible = not GameManager.low_spec


func _build_viewmodel() -> void:
    # A simple flashlight held at the lower right of the screen.
    var holder := Node3D.new()
    holder.position = Vector3(0.26, -0.24, -0.5)
    holder.rotation_degrees = Vector3(-6.0, 4.0, 0.0)
    camera.add_child(holder)
    _holder = holder
    var body_mat := StandardMaterial3D.new()
    body_mat.albedo_color = Color(0.05, 0.05, 0.06)
    body_mat.metallic = 0.6
    body_mat.roughness = 0.4
    var tube := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.032
    cm.bottom_radius = 0.026
    cm.height = 0.26
    cm.material = body_mat
    tube.mesh = cm
    tube.rotation_degrees = Vector3(90.0, 0.0, 0.0)
    tube.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    holder.add_child(tube)
    var head_m := MeshInstance3D.new()
    var hm := CylinderMesh.new()
    hm.top_radius = 0.052
    hm.bottom_radius = 0.034
    hm.height = 0.07
    hm.material = body_mat
    head_m.mesh = hm
    head_m.rotation_degrees = Vector3(90.0, 0.0, 0.0)
    head_m.position = Vector3(0.0, 0.0, -0.15)
    head_m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    holder.add_child(head_m)
    _lens_mat = StandardMaterial3D.new()
    _lens_mat.albedo_color = Color(0.1, 0.1, 0.1)
    _lens_mat.emission_enabled = true
    _lens_mat.emission = Color(1.0, 0.95, 0.8)
    _lens_mat.emission_energy_multiplier = 0.0
    var lens := MeshInstance3D.new()
    var lm := CylinderMesh.new()
    lm.top_radius = 0.045
    lm.bottom_radius = 0.045
    lm.height = 0.004
    lm.material = _lens_mat
    lens.mesh = lm
    lens.rotation_degrees = Vector3(90.0, 0.0, 0.0)
    lens.position = Vector3(0.0, 0.0, -0.187)
    lens.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    holder.add_child(lens)


func _unhandled_input(event: InputEvent) -> void:
    if frozen or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
        return
    if event is InputEventMouseMotion:
        var sens: float = GameManager.get_mouse_sensitivity()
        _sway_target += Vector2(event.relative.x, event.relative.y) * 0.0009
        _sway_target = _sway_target.clamp(Vector2(-0.12, -0.12), Vector2(0.12, 0.12))
        rotate_y(-event.relative.x * sens)
        head.rotate_x(-event.relative.y * sens)
        head.rotation.x = clampf(head.rotation.x, deg_to_rad(-85.0), deg_to_rad(85.0))
    if event.is_action_pressed("interact"):
        _try_interact()
    if event.is_action_pressed("flashlight"):
        _toggle_flashlight()


func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= 9.8 * delta

    var input_dir := Vector2.ZERO
    if not frozen:
        input_dir = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var direction: Vector3 = (transform.basis * Vector3(input_dir.x, 0.0, input_dir.y)).normalized()
    var moving: bool = direction != Vector3.ZERO

    is_crouching = (not frozen) and Input.is_action_pressed("crouch")
    var target_height: float = crouch_head_height if is_crouching else stand_head_height
    head.position.y = lerpf(head.position.y, target_height, 10.0 * delta)

    var sprinting: bool = (
        (not frozen) and Input.is_action_pressed("sprint") and moving
        and not is_crouching and not exhausted and stamina > 0.0
    )
    if sprinting:
        stamina = maxf(stamina - stamina_drain * delta, 0.0)
        _regen_timer = regen_delay
        if stamina <= 0.0:
            exhausted = true
    else:
        _regen_timer -= delta
        if _regen_timer <= 0.0:
            stamina = minf(stamina + stamina_regen * delta, max_stamina)
        if exhausted and stamina >= exhausted_recover_at:
            exhausted = false

    var speed: float = walk_speed
    if is_crouching:
        speed = crouch_speed
    elif sprinting:
        speed = sprint_speed

    velocity.x = move_toward(velocity.x, direction.x * speed, acceleration * delta)
    velocity.z = move_toward(velocity.z, direction.z * speed, acceleration * delta)
    move_and_slide()
    _sprinting = sprinting

    if moving and is_on_floor():
        _step_timer -= delta
        if _step_timer <= 0.0:
            if sprinting:
                _step_timer = 0.34
            elif is_crouching:
                _step_timer = 0.8
            else:
                _step_timer = 0.52
            _step_audio.pitch_scale = randf_range(0.85, 1.15)
            _step_audio.volume_db = (-22.0 if is_crouching else -14.0) + GameManager.audio_offset()
            _step_audio.play()
    else:
        _step_timer = 0.0


func _process(delta: float) -> void:
    _update_flashlight(delta)
    _update_prompt()
    _update_camera_motion(delta)
    if _shake > 0.0:
        _shake = maxf(_shake - delta * 0.1, 0.0)
        camera.h_offset = randf_range(-1.0, 1.0) * _shake
        camera.v_offset = randf_range(-1.0, 1.0) * _shake
    else:
        camera.h_offset = 0.0
        camera.v_offset = 0.0


# Head bob, breathing, strafe lean, sprint FOV kick and flashlight inertia.
func _update_camera_motion(delta: float) -> void:
    var spd: float = Vector2(velocity.x, velocity.z).length()
    var reduce: float = 0.3 if GameManager.disable_shake else 1.0
    var target_amp: float = clampf(spd / walk_speed, 0.0, 1.7) if (is_on_floor() and not frozen) else 0.0
    _bob_amp = lerpf(_bob_amp, target_amp, minf(delta * 8.0, 1.0))
    _bob_t += delta * (spd * 2.1 + 0.001)
    _breath_t += delta
    var crouch_k: float = 0.6 if is_crouching else 1.0
    var bob := Vector3(
        sin(_bob_t * 0.5) * 0.018 * _bob_amp * crouch_k,
        absf(sin(_bob_t * 0.5)) * 0.032 * _bob_amp * crouch_k - 0.01 * _bob_amp,
        0.0) * reduce
    var breath: float = sin(_breath_t * 1.4) * 0.0035 * reduce
    camera.position = bob + Vector3(0.0, breath, 0.0)
    camera.rotation.x = breath * 0.8
    var lean: float = 0.0
    if not frozen:
        lean = -Input.get_axis("move_left", "move_right") * 0.018 * reduce
    camera.rotation.z = lerpf(camera.rotation.z, lean + sin(_bob_t * 0.5) * 0.004 * _bob_amp * reduce, minf(delta * 8.0, 1.0))
    var fov_target: float = 75.0 + (5.0 if _sprinting else 0.0)
    camera.fov = lerpf(camera.fov, fov_target, minf(delta * 6.0, 1.0))
    # flashlight is hand-held: it lags behind fast turns and bobs with the steps
    _sway_target = _sway_target.lerp(Vector2.ZERO, minf(delta * 6.0, 1.0))
    _sway = _sway.lerp(_sway_target, minf(delta * 12.0, 1.0))
    flashlight.position = bob + Vector3(0.06, -0.05, 0.0)
    flashlight.rotation = Vector3(_sway.y, _sway.x, 0.0) * reduce
    _spill.position = flashlight.position
    _spill.rotation = flashlight.rotation
    if _holder != null:
        _holder.position = Vector3(0.26, -0.24, -0.5) + bob * 0.8
        _holder.rotation_degrees = Vector3(-6.0, 4.0, 0.0) + Vector3(rad_to_deg(_sway.y), rad_to_deg(_sway.x), 0.0) * 0.6


func add_shake(amount: float) -> void:
    if GameManager.disable_shake:
        return
    _shake = maxf(_shake, amount)


func get_forward_flat() -> Vector3:
    var f: Vector3 = -global_transform.basis.z
    f.y = 0.0
    return f.normalized()


func teleport(pos: Vector3, yaw: float) -> void:
    global_position = pos
    rotation.y = yaw
    velocity = Vector3.ZERO
    head.rotation.x = 0.0


func _toggle_flashlight() -> void:
    AudioBank.play_ui(self, "click", -8.0)
    if flashlight.visible:
        flashlight.visible = false
    elif battery >= battery_min_to_turn_on:
        flashlight.visible = true


func _update_flashlight(delta: float) -> void:
    if _spill != null:
        _spill.visible = flashlight.visible
        _spill.light_energy = flashlight.light_energy * 0.1
    if _lens_mat != null:
        _lens_mat.emission_energy_multiplier = 2.5 if flashlight.visible else 0.0
    if flashlight.visible:
        battery = maxf(battery - battery_drain * delta, 0.0)
        if battery <= 0.0:
            flashlight.visible = false
        elif battery < 20.0 and randf() < 0.08:
            flashlight.light_energy = _flash_energy * randf_range(0.2, 1.0)
        else:
            flashlight.light_energy = lerpf(flashlight.light_energy, _flash_energy, 0.3)
    else:
        battery = minf(battery + battery_recharge * delta, max_battery)


func _try_interact() -> void:
    if interact_ray.is_colliding():
        var target = interact_ray.get_collider()
        if target != null and target.has_method("interact"):
            target.interact(self)


func _update_prompt() -> void:
    var text: String = ""
    if not frozen and interact_ray.is_colliding():
        var target = interact_ray.get_collider()
        if target != null and target.has_method("get_prompt"):
            text = target.get_prompt()
    if text != _last_prompt:
        _last_prompt = text
        prompt_changed.emit(text)

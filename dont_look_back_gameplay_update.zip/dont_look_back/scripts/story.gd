extends RefCounted
# All written content. Original text. Each function returns [title, body].


static func note_start() -> Array:
    return ["HANDWRITTEN LOG - BAY 0", "\n".join([
        "If you are reading this, you woke up in Bay 0. Do not panic. The emergency lights have been looping for days. That is normal now.",
        "",
        "Three access fragments keep the main exit sealed. One in Security, one in Storage, one in the Research Lab. The power console wants two of them before it will wake the building.",
        "",
        "Something walks these halls. I have never seen it move. I have only seen it closer.",
        "",
        "- D.",
    ])]


static func note_security() -> Array:
    return ["SECURITY LOG - NIGHT 41", "\n".join([
        "Camera 4 shows the east corridor empty. Camera 4 also shows a figure standing at the far end, facing the lens. It is wearing my coat.",
        "",
        "I logged it as a sensor fault. The radio keeps repeating one phrase: DON'T LOOK BACK.",
        "",
        "I am starting to think it is not a warning. I think it is an instruction.",
        "",
        "The first fragment is on the desk. It hums when I look away.",
    ])]


static func note_storage() -> Array:
    return ["INVENTORY - STORAGE B", "\n".join([
        "Crate 12: flashlight cells. Drained. They recharge if you switch the light off and wait. Do not ask me how.",
        "",
        "Crate 15: not on any manifest. Humming. Nobody ordered it and nobody will open it.",
        "",
        "The second fragment is sitting on top of Crate 15, because it is the only place it will stay put.",
        "",
        "Reminder: whatever follows you cannot move while you are looking at it. Eyes up, people.",
    ])]


static func note_power() -> Array:
    return ["POWER MAINTENANCE NOTICE", "\n".join([
        "Seat two access fragments in the console reader. Main power will return and the Research Lab will unseal.",
        "",
        "Warning: when the lights stop flickering, the building stops pretending nobody is here.",
        "",
        "After the third fragment, do not stop. Go east, to the main exit. If it gets close, turn and face it. Hold its gaze. It cannot move while it is seen.",
    ])]


static func note_lab() -> Array:
    return ["RESEARCH NOTE R-9", "\n".join([
        "Project: THE ANCHOR. A building this large cannot hold its shape unobserved, so someone has to keep watching.",
        "",
        "Volunteer 0 held the facility together for eleven days without sleep. On the twelfth, it stopped being a person watching the building and became the thing the building watches.",
        "",
        "We call it the Watcher. We do not call it by Volunteer 0's name.",
    ])]


static func recording() -> Array:
    return ["RECORDING - VOICE LOG (IT IS YOUR VOICE)", "\n".join([
        "[static]",
        "",
        "This is a message to myself. If it is playing, the loop has restarted and you do not remember recording this.",
        "",
        "Every cycle I leave a part of me behind to watch the door while the rest of me walks out. It follows you because it wants to be seen. It is lonely, and it is me.",
        "",
        "Do not run forever. Turn around. Look at it. Three full seconds, if you can stand it. Then walk out.",
        "",
        "- You",
    ])]


static func ending_good() -> Array:
    return ["YOU LOOKED BACK", "\n".join([
        "For three seconds you held its gaze, and the corridor stopped pretending to be anywhere else.",
        "",
        "The thing that followed you was never hunting. It was the part of you that stays behind every cycle, waiting for someone to finally turn around and see it.",
        "",
        "It stood very still. Then, slowly, it nodded.",
        "",
        "The door is open. For the first time, the loop has no one left to keep.",
        "",
        "ENDING 1 OF 2 - ACKNOWLEDGED",
    ])]


static func ending_loop() -> Array:
    return ["THE LOOP", "\n".join([
        "You never held its gaze. The door seals behind you and the morning outside is very quiet.",
        "",
        "Somewhere in the facility, in your own voice, a radio begins to play:",
        "'Emergency... Bay Zero... if anyone can hear this... find the three fragments... and don't look back.'",
        "",
        "In the corridor, something finally moves.",
        "",
        "ENDING 2 OF 2 - THE LOOP",
        "(Hint: try again, and turn around.)",
    ])]

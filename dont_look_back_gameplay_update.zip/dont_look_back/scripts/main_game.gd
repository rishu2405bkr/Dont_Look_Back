extends Node3D
# DON'T LOOK BACK - level builder and game flow.
# The whole facility is generated from code (boxes, cylinders, lights),
# so there are no scene files that can break. Everything here is original.
#
# Layout (x = east, z = south, meters):
#   Start room    x -10..-2   z -4..4
#   Main corridor x  -2..56   z -2..2    (final escape corridor = x 32..56)
#   Security      x   2..10   z -10..-2  (north of corridor)
#   Power room    x  14..24   z -10..-2  (north of corridor)
#   Storage       x   2..10   z 2..10    (south of corridor)
#   Research lab  x  14..28   z 2..14    (south of corridor)
#   Main exit     x  56 (door), outside courtyard x 56..64

const AudioBank = preload("res://scripts/audio_bank.gd")
const Story = preload("res://scripts/story.gd")
const PlayerScript = preload("res://scripts/player.gd")
const InteractableScript = preload("res://scripts/interactable.gd")
const FlickerLightScript = preload("res://scripts/flicker_light.gd")
const WatcherScript = preload("res://scripts/watcher.gd")
const DirectorScript = preload("res://scripts/horror_director.gd")
const HudScript = preload("res://scripts/hud.gd")
const PauseScript = preload("res://scripts/pause_menu.gd")
const TexGen = preload("res://scripts/tex_gen.gd")
const PostFxScript = preload("res://scripts/postfx.gd")

const WALL_H: float = 3.0
const WALL_T: float = 0.3

var player
var watcher
var director
var hud
var pause_menu
var env: Environment
var geo_root: Node3D
var grain_tex: ImageTexture
var lights: Array = []
var fragment_meshes: Array = []
var door_info: Dictionary = {}
var exit_body
var exit_light: OmniLight3D
var console_screen_mat: StandardMaterial3D
var console_body
var fuse_body
var fuse_collected: bool = false
var postfx
var fog_volumes: Array = []
var particle_fx: Array = []
var _stress: float = 0.0
var m_rubber: StandardMaterial3D
var m_red: StandardMaterial3D
var m_cable: StandardMaterial3D
var m_brass: StandardMaterial3D
var m_cloth: StandardMaterial3D

var chase_on: bool = false
var exit_open: bool = false
var ending_started: bool = false
var catching: bool = false
var checkpoint: Vector3 = Vector3(22.0, 0.1, 0.0)
var note_opened_at: int = 0

var m_wall: StandardMaterial3D
var m_floor: StandardMaterial3D
var m_ceil: StandardMaterial3D
var m_door: StandardMaterial3D
var m_wood: StandardMaterial3D
var m_crate: StandardMaterial3D
var m_metal: StandardMaterial3D
var m_paper: StandardMaterial3D
var m_screen: StandardMaterial3D
var m_glass: StandardMaterial3D
var m_stripe: StandardMaterial3D
var m_fragment: StandardMaterial3D
var m_puddle: StandardMaterial3D
var m_sheet: StandardMaterial3D
var m_wainscot: StandardMaterial3D
var m_dark: StandardMaterial3D


func _ready() -> void:
    GameManager.reset_run()
    geo_root = Node3D.new()
    geo_root.name = "Facility"
    add_child(geo_root)

    _make_materials()
    _build_environment()
    _build_geometry()
    _build_doors()
    _build_props()
    _build_debris()
    _build_detail()
    _build_decals()
    _build_lights()
    _build_probes()
    _spawn_player()
    _spawn_watcher()
    _build_ui()
    _build_director()

    GameManager.settings_changed.connect(_apply_quality)
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    _update_objective()
    _intro()


# =====================================================================
#  MATERIALS / ENVIRONMENT
# =====================================================================

func _make_grain() -> ImageTexture:
    var img := Image.create_empty(128, 128, false, Image.FORMAT_RGB8)
    var rng := RandomNumberGenerator.new()
    rng.seed = 7
    for y in 128:
        for x in 128:
            var v: float = 0.82 + rng.randf() * 0.18
            img.set_pixel(x, y, Color(v, v, v))
    return ImageTexture.create_from_image(img)


func _mat(color: Color, rough: float = 0.9, metal: float = 0.0, grain: bool = true) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = rough
    m.metallic = metal
    if grain:
        m.albedo_texture = grain_tex
        m.uv1_triplanar = true
        m.uv1_world_triplanar = true
        m.uv1_scale = Vector3(0.6, 0.6, 0.6)
    return m


func _pbr(kind: String, tint: Color, uv: float, metal: float) -> StandardMaterial3D:
    var d: Dictionary = TexGen.get_set(kind)
    var m := StandardMaterial3D.new()
    m.albedo_color = tint
    m.albedo_texture = d["albedo"]
    m.normal_enabled = true
    m.normal_texture = d["normal"]
    m.normal_scale = 1.0
    m.roughness = 1.0
    m.roughness_texture = d["rough"]
    m.metallic = metal
    m.ao_enabled = true
    m.ao_texture = d["ao"]
    m.ao_light_affect = 0.55
    m.uv1_triplanar = true
    m.uv1_world_triplanar = true
    m.uv1_triplanar_sharpness = 4.0
    m.uv1_scale = Vector3(uv, uv, uv)
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    return m


func _glow(color: Color, energy: float) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color.darkened(0.7)
    m.emission_enabled = true
    m.emission = color
    m.emission_energy_multiplier = energy
    return m


func _make_materials() -> void:
    m_wall = _pbr("plaster", Color(0.85, 0.95, 1.05), 0.4, 0.0)
    m_floor = _pbr("tile", Color(1.0, 1.0, 1.0), 0.8, 0.0)   # wet tiles
    m_ceil = _pbr("concrete", Color(1.0, 1.0, 1.0), 0.5, 0.0)
    m_door = _pbr("metal", Color(1.1, 1.15, 1.2), 0.9, 0.6)
    m_wood = _pbr("wood", Color(1.0, 1.0, 1.0), 1.0, 0.0)
    m_crate = _pbr("crate", Color(1.0, 1.0, 1.0), 1.0, 0.0)
    m_metal = _pbr("metal", Color(1.0, 1.0, 1.0), 1.0, 0.75)
    m_paper = _glow(Color(0.85, 0.82, 0.7), 0.5)
    m_screen = _glow(Color(0.2, 0.7, 0.85), 1.6)
    m_stripe = _glow(Color(0.8, 0.15, 0.1), 1.2)
    m_fragment = _glow(Color(1.0, 0.7, 0.2), 3.0)
    console_screen_mat = _glow(Color(0.9, 0.15, 0.1), 1.8)
    m_puddle = _mat(Color(0.02, 0.03, 0.04), 0.03, 0.9, false)
    m_sheet = _mat(Color(0.78, 0.76, 0.68), 0.95, 0.0, false)
    m_wainscot = _pbr("plaster", Color(0.35, 0.75, 0.62), 0.4, 0.0)
    m_dark = _mat(Color(0.06, 0.07, 0.08), 0.6, 0.3, false)
    m_rubber = _mat(Color(0.03, 0.03, 0.035), 0.85, 0.0, false)
    m_red = _mat(Color(0.5, 0.04, 0.03), 0.35, 0.2, false)
    m_cable = _mat(Color(0.02, 0.02, 0.022), 0.55, 0.0, false)
    m_brass = _mat(Color(0.55, 0.42, 0.2), 0.4, 0.9, false)
    m_cloth = _mat(Color(0.2, 0.22, 0.21), 1.0, 0.0, false)
    # wet look on the floor: a thin glossy clearcoat over the tiles, and rough-ish glossy ceiling paint
    m_floor.clearcoat_enabled = true
    m_floor.clearcoat = 0.55
    m_floor.clearcoat_roughness = 0.1
    m_floor.normal_scale = 1.2
    m_wall.normal_scale = 1.3
    m_wainscot.clearcoat_enabled = true
    m_wainscot.clearcoat = 0.25
    m_wainscot.clearcoat_roughness = 0.35
    m_glass = StandardMaterial3D.new()
    m_glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m_glass.albedo_color = Color(0.5, 0.9, 0.9, 0.22)
    m_glass.emission_enabled = true
    m_glass.emission = Color(0.2, 0.7, 0.65)
    m_glass.emission_energy_multiplier = 0.8


# Sets a property only if this Godot version has it (keeps the project working across 4.x versions).
func _set_if(obj: Object, prop: String, value) -> void:
    if prop in obj:
        obj.set(prop, value)


func _build_environment() -> void:
    env = Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.03, 0.04, 0.06)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.2, 0.26, 0.34)
    env.ambient_light_energy = 0.4
    env.tonemap_mode = Environment.TONE_MAPPER_ACES
    env.tonemap_exposure = 1.0
    # ambient occlusion + indirect bounce light (the "light leaking into corners" realism)
    env.ssao_enabled = true
    env.ssao_radius = 1.2
    env.ssao_intensity = 2.6
    env.ssao_power = 1.6
    env.ssao_detail = 0.7
    env.ssao_light_affect = 0.3
    _set_if(env, "ssao_ao_channel_affect", 0.5)
    _set_if(env, "ssil_enabled", true)
    _set_if(env, "ssil_radius", 4.0)
    _set_if(env, "ssil_intensity", 1.2)
    _set_if(env, "ssil_sharpness", 0.98)
    env.ssr_enabled = true
    env.ssr_max_steps = 96
    env.ssr_fade_in = 0.15
    env.ssr_fade_out = 2.0
    env.ssr_depth_tolerance = 0.2
    env.fog_enabled = true
    env.fog_light_color = Color(0.07, 0.09, 0.12)
    env.fog_density = 0.014
    _set_if(env, "fog_aerial_perspective", 0.2)
    env.glow_enabled = true
    env.glow_intensity = 0.7
    env.glow_strength = 1.1
    env.glow_bloom = 0.04
    env.glow_hdr_threshold = 0.9
    env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
    env.adjustment_enabled = true
    env.adjustment_contrast = 1.1
    env.adjustment_saturation = 0.82
    env.volumetric_fog_enabled = true
    env.volumetric_fog_density = 0.02
    env.volumetric_fog_albedo = Color(0.35, 0.42, 0.52)
    env.volumetric_fog_emission = Color(0.01, 0.015, 0.02)
    env.volumetric_fog_length = 40.0
    _set_if(env, "volumetric_fog_anisotropy", 0.6)
    _set_if(env, "volumetric_fog_ambient_inject", 0.2)
    _set_if(env, "volumetric_fog_temporal_reprojection_enabled", true)
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    _apply_quality()


func _apply_quality() -> void:
    if env == null:
        return
    var low: bool = GameManager.low_spec
    env.volumetric_fog_enabled = not low
    env.glow_enabled = not low
    env.ssr_enabled = not low
    env.ssao_enabled = not low
    _set_if(env, "ssil_enabled", not low)
    for l in lights:
        l.shadow_enabled = not low
    # anti-aliasing, sharper shadows and crisper textures at a distance
    var vp: Viewport = get_viewport()
    if vp != null:
        vp.msaa_3d = Viewport.MSAA_DISABLED if low else Viewport.MSAA_4X
        _set_if(vp, "use_taa", not low)
        _set_if(vp, "screen_space_aa", Viewport.SCREEN_SPACE_AA_FXAA if low else Viewport.SCREEN_SPACE_AA_DISABLED)
        _set_if(vp, "positional_shadow_atlas_size", 2048 if low else 4096)
        _set_if(vp, "anisotropic_filtering_level", 2 if low else 4)
    RenderingServer.positional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_LOW if low else RenderingServer.SHADOW_QUALITY_SOFT_HIGH)
    for fv in fog_volumes:
        if is_instance_valid(fv):
            fv.visible = not low
    for pr in particle_fx:
        if is_instance_valid(pr):
            pr.visible = not low


# =====================================================================
#  GEOMETRY HELPERS
# =====================================================================

func _solid(pos: Vector3, size: Vector3, mat: Material, body_override = null) -> StaticBody3D:
    var body: StaticBody3D = body_override if body_override != null else StaticBody3D.new()
    body.position = pos
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    bm.material = mat
    mi.mesh = bm
    body.add_child(mi)
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = size
    cs.shape = bs
    body.add_child(cs)
    geo_root.add_child(body)
    return body


func _deco(pos: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    bm.material = mat
    mi.mesh = bm
    mi.position = pos
    geo_root.add_child(mi)
    return mi


func _cyl(pos: Vector3, radius: float, height: float, mat: Material, horizontal: bool = false, collide: bool = true) -> Node3D:
    var root: Node3D
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = radius
    cm.bottom_radius = radius
    cm.height = height
    cm.material = mat
    mi.mesh = cm
    if collide:
        var body := StaticBody3D.new()
        body.add_child(mi)
        var cs := CollisionShape3D.new()
        var sh := CylinderShape3D.new()
        sh.radius = radius
        sh.height = height
        cs.shape = sh
        body.add_child(cs)
        root = body
    else:
        root = mi
    root.position = pos
    if horizontal:
        root.rotation_degrees = Vector3(0.0, 0.0, 90.0)
    geo_root.add_child(root)
    return root


func _sign(text: String, pos: Vector3, yaw: float, color: Color = Color(0.75, 0.85, 0.95), px: float = 0.006) -> void:
    var l := Label3D.new()
    l.text = text
    l.font_size = 64
    l.pixel_size = px
    l.modulate = color
    l.position = pos
    l.rotation.y = yaw
    geo_root.add_child(l)


# Wall along X at fixed z, from x0 to x1, with door gaps given as [[g0, g1], ...]
func _wall_x(z: float, x0: float, x1: float, gaps: Array = []) -> void:
    var cur: float = x0 - WALL_T * 0.5
    var end: float = x1 + WALL_T * 0.5
    for g in gaps:
        var g0: float = g[0]
        var g1: float = g[1]
        if g0 > cur:
            _solid(Vector3((cur + g0) * 0.5, WALL_H * 0.5, z), Vector3(g0 - cur, WALL_H, WALL_T), m_wall)
        _solid(Vector3((g0 + g1) * 0.5, 2.8, z), Vector3(g1 - g0, 0.4, WALL_T), m_wall)
        cur = g1
    if end > cur:
        _solid(Vector3((cur + end) * 0.5, WALL_H * 0.5, z), Vector3(end - cur, WALL_H, WALL_T), m_wall)


# Wall along Z at fixed x, from z0 to z1
func _wall_z(x: float, z0: float, z1: float, gaps: Array = []) -> void:
    var cur: float = z0 - WALL_T * 0.5
    var end: float = z1 + WALL_T * 0.5
    for g in gaps:
        var g0: float = g[0]
        var g1: float = g[1]
        if g0 > cur:
            _solid(Vector3(x, WALL_H * 0.5, (cur + g0) * 0.5), Vector3(WALL_T, WALL_H, g0 - cur), m_wall)
        _solid(Vector3(x, 2.8, (g0 + g1) * 0.5), Vector3(WALL_T, 0.4, g1 - g0), m_wall)
        cur = g1
    if end > cur:
        _solid(Vector3(x, WALL_H * 0.5, (cur + end) * 0.5), Vector3(WALL_T, WALL_H, end - cur), m_wall)


# =====================================================================
#  LEVEL GEOMETRY
# =====================================================================

func _build_geometry() -> void:
    _solid(Vector3(27.0, -0.2, 2.0), Vector3(80.0, 0.4, 30.0), m_floor)
    _solid(Vector3(23.0, 3.1, 2.0), Vector3(68.0, 0.2, 26.0), m_ceil)

    # Start room
    _wall_x(-4.0, -10.0, -2.0)
    _wall_x(4.0, -10.0, -2.0)
    _wall_z(-10.0, -4.0, 4.0)
    _wall_z(-2.0, -4.0, 4.0, [[-1.0, 1.0]])

    # Main corridor + final escape corridor
    _wall_x(-2.0, -2.0, 56.0, [[5.0, 7.0], [18.0, 20.0]])
    _wall_x(2.0, -2.0, 56.0, [[5.0, 7.0], [19.0, 21.0]])

    # Security office
    _wall_z(2.0, -10.0, -2.0)
    _wall_z(10.0, -10.0, -2.0)
    _wall_x(-10.0, 2.0, 10.0)

    # Power room
    _wall_z(14.0, -10.0, -2.0)
    _wall_z(24.0, -10.0, -2.0)
    _wall_x(-10.0, 14.0, 24.0)

    # Storage room
    _wall_z(2.0, 2.0, 10.0)
    _wall_z(10.0, 2.0, 10.0)
    _wall_x(10.0, 2.0, 10.0)

    # Research lab
    _wall_z(14.0, 2.0, 14.0)
    _wall_z(28.0, 2.0, 14.0)
    _wall_x(14.0, 14.0, 28.0)

    # Exit wall and the courtyard outside
    _wall_z(56.0, -2.0, 2.0, [[-1.2, 1.2]])
    _wall_z(56.0, -4.0, -2.0)
    _wall_z(56.0, 2.0, 4.0)
    _wall_x(-4.0, 56.0, 64.0)
    _wall_x(4.0, 56.0, 64.0)
    _wall_z(64.0, -4.0, 4.0)

    # Corridor ribs (decoration only, no collision) for a modular look
    for x in [0.0, 3.0, 9.0, 13.0, 16.0, 23.0, 27.0, 31.0, 35.0, 39.0, 43.0, 47.0, 51.0, 54.0]:
        _deco(Vector3(x, 1.5, -1.78), Vector3(0.25, 3.0, 0.2), m_metal)
        _deco(Vector3(x, 1.5, 1.78), Vector3(0.25, 3.0, 0.2), m_metal)

    # Red hazard stripes along the final escape corridor
    _deco(Vector3(44.0, 1.1, -1.82), Vector3(24.0, 0.1, 0.02), m_stripe)
    _deco(Vector3(44.0, 1.1, 1.82), Vector3(24.0, 0.1, 0.02), m_stripe)

    # Two-tone painted lower walls (teal-green), skipping the door gaps
    _wainscot(-1.845, 0.0, 56.0, [[5.0, 7.0], [18.0, 20.0]])
    _wainscot(1.845, 0.0, 56.0, [[5.0, 7.0], [19.0, 21.0]])

    # Pipes
    _cyl(Vector3(44.0, 2.7, -1.6), 0.1, 24.0, m_metal, true, false)
    _cyl(Vector3(44.0, 2.5, -1.6), 0.07, 24.0, m_metal, true, false)
    _cyl(Vector3(8.0, 2.7, 1.6), 0.1, 12.0, m_metal, true, false)

    # Direction signs (they face the side the player walks on)
    _sign("-> MAIN CORRIDOR", Vector3(-2.2, 2.2, 0.0), -PI / 2.0)
    _sign("SECURITY", Vector3(6.0, 2.3, -1.83), 0.0)
    _sign("POWER", Vector3(19.0, 2.3, -1.83), 0.0)
    _sign("STORAGE", Vector3(6.0, 2.3, 1.83), PI)
    _sign("RESEARCH LAB", Vector3(20.0, 2.3, 1.83), PI)
    _sign("EXIT >>", Vector3(30.0, 2.2, -1.83), 0.0, Color(0.5, 1.0, 0.6))
    _sign("EXIT >>", Vector3(42.0, 2.2, 1.83), PI, Color(0.5, 1.0, 0.6))
    _sign("MAIN EXIT", Vector3(55.8, 2.8, 0.0), -PI / 2.0, Color(0.5, 1.0, 0.6), 0.007)
    _sign("B1\nSECTOR", Vector3(1.5, 1.9, 1.83), PI, Color(0.88, 0.88, 0.82), 0.011)
    _sign("SPECIMEN 0", Vector3(21.0, 2.1, 13.83), PI, Color(0.5, 0.95, 0.9))


func _wainscot(z: float, x0: float, x1: float, gaps: Array) -> void:
    var cur: float = x0
    for g in gaps:
        var g0: float = g[0]
        var g1: float = g[1]
        if g0 > cur:
            _wainscot_seg(z, cur, g0)
        cur = g1
    if x1 > cur:
        _wainscot_seg(z, cur, x1)


func _wainscot_seg(z: float, a: float, b: float) -> void:
    var mid: float = (a + b) * 0.5
    var inward: float = -signf(z) * 0.014
    _deco(Vector3(mid, 0.65, z), Vector3(b - a, 1.3, 0.01), m_wainscot)
    _deco(Vector3(mid, 0.07, z + inward), Vector3(b - a, 0.14, 0.03), m_dark)
    _deco(Vector3(mid, 1.32, z + inward * 0.5), Vector3(b - a, 0.04, 0.03), m_metal)


# =====================================================================
#  EXTRA REALISM: ceiling structure, cables, vents, drains, extinguishers,
#  rubble, dripping water, steam, haze, reflection probes
# =====================================================================

func _build_detail() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 4242

    # structural ceiling beams across the corridor (between the light fixtures)
    for x in range(0, 56, 4):
        _deco(Vector3(float(x), 2.93, 0.0), Vector3(0.22, 0.14, 3.62), m_metal)
        _deco(Vector3(float(x), 2.84, 0.0), Vector3(0.3, 0.03, 3.62), m_dark)

    # cable tray with a bundle of cables running the length of the corridor
    _deco(Vector3(27.0, 2.9, 0.95), Vector3(58.0, 0.04, 0.4), m_dark)
    _deco(Vector3(27.0, 2.94, 0.76), Vector3(58.0, 0.08, 0.02), m_metal)
    _deco(Vector3(27.0, 2.94, 1.14), Vector3(58.0, 0.08, 0.02), m_metal)
    for i in 7:
        var cz: float = 0.82 + 0.05 * float(i)
        _cyl(Vector3(27.0, 2.93 + 0.01 * float(i % 2), cz), 0.012 + 0.004 * float(i % 3), 58.0, m_cable, true, false)
    # a few cables hanging loose from the tray
    for hx in [11.5, 25.5, 37.0, 47.5]:
        var cab := _cyl(Vector3(hx, 2.55, 0.95), 0.012, 0.8, m_cable, false, false)
        cab.rotation_degrees = Vector3(rng.randf_range(-12.0, 12.0), 0.0, rng.randf_range(-12.0, 12.0))

    # ventilation grilles in the ceiling
    for vx in [8.0, 22.0, 30.0, 40.0, 48.0]:
        _deco(Vector3(vx, 2.97, -0.9), Vector3(0.7, 0.05, 0.5), m_metal)
        for k in 5:
            _deco(Vector3(vx, 2.94, -1.08 + 0.09 * float(k)), Vector3(0.62, 0.015, 0.02), m_dark)

    # fire extinguishers on the walls
    for ex in [11.5, 31.5, 47.5]:
        _cyl(Vector3(ex, 0.95, -1.76), 0.07, 0.34, m_red, false, false)
        _deco(Vector3(ex, 1.17, -1.76), Vector3(0.06, 0.06, 0.06), m_dark)
        _deco(Vector3(ex, 0.95, -1.82), Vector3(0.18, 0.5, 0.02), m_rubber)
        _sign("EXTINGUISHER", Vector3(ex, 1.55, -1.83), 0.0, Color(0.9, 0.2, 0.15), 0.0025)

    # electrical conduit boxes and vertical conduits on the south wall
    for cx in [13.0, 16.5, 33.0, 45.0]:
        _deco(Vector3(cx, 1.5, 1.77), Vector3(0.28, 0.36, 0.1), m_metal)
        _deco(Vector3(cx, 1.5, 1.72), Vector3(0.22, 0.28, 0.02), m_dark)
        _cyl(Vector3(cx + 0.06, 2.3, 1.77), 0.018, 1.6, m_dark, false, false)

    # floor drains with grates
    for dx in [16.0, 36.0, 52.0]:
        _deco(Vector3(dx, 0.008, 0.5), Vector3(0.5, 0.012, 0.5), m_dark)
        for k in 5:
            _deco(Vector3(dx, 0.016, 0.3 + 0.1 * float(k)), Vector3(0.46, 0.008, 0.02), m_metal)

    # expansion joints in the floor
    for jx in range(4, 56, 6):
        _deco(Vector3(float(jx), 0.004, 0.0), Vector3(0.025, 0.006, 3.6), m_dark)

    # rubble: plaster chunks and dust that fell from the ceiling (no collision, kept to the sides)
    for i in 70:
        var side: float = -1.0 if rng.randf() < 0.5 else 1.0
        var pos := Vector3(rng.randf_range(0.0, 55.0), 0.02, side * rng.randf_range(0.9, 1.7))
        var sz := Vector3(rng.randf_range(0.03, 0.14), rng.randf_range(0.015, 0.05), rng.randf_range(0.03, 0.12))
        var ch := _deco(pos, sz, m_wall)
        ch.rotation_degrees = Vector3(rng.randf_range(-10.0, 10.0), rng.randf_range(0.0, 360.0), rng.randf_range(-10.0, 10.0))

    # dripping water (with a puddle underneath each leak)
    for dp in [Vector3(8.5, 2.95, -0.9), Vector3(21.0, 2.95, 1.2), Vector3(29.5, 2.95, -0.4), Vector3(38.5, 2.95, 0.7), Vector3(47.0, 2.95, -1.1)]:
        _drip(dp)
        _deco(Vector3(dp.x, 0.006, dp.z), Vector3(0.9, 0.008, 0.9), m_puddle)

    # steam leaking from the pipe in the power room, and from the lab
    _steam(Vector3(16.5, 2.45, -9.5))
    _steam(Vector3(24.5, 0.2, 12.5))

    # low red haze in the final escape corridor and a cold haze in the main corridor
    _fog_volume(Vector3(44.0, 1.4, 0.0), Vector3(24.0, 2.8, 3.6), Color(0.75, 0.25, 0.2), 0.3)
    _fog_volume(Vector3(14.0, 0.5, 0.0), Vector3(30.0, 1.0, 3.6), Color(0.6, 0.7, 0.8), 0.18)


func _drip(pos: Vector3) -> void:
    var g := GPUParticles3D.new()
    g.amount = 2
    g.lifetime = 0.9
    g.preprocess = 2.0
    g.local_coords = true
    g.position = pos
    g.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    g.visibility_aabb = AABB(Vector3(-1.0, -4.0, -1.0), Vector3(2.0, 4.5, 2.0))
    var pm := ParticleProcessMaterial.new()
    pm.direction = Vector3(0.0, -1.0, 0.0)
    pm.spread = 0.0
    pm.initial_velocity_min = 0.0
    pm.initial_velocity_max = 0.0
    pm.gravity = Vector3(0.0, -9.8, 0.0)
    g.process_material = pm
    var qm := QuadMesh.new()
    qm.size = Vector2(0.006, 0.05)
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    mat.billboard_keep_scale = true
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.albedo_color = Color(0.7, 0.8, 0.9, 0.35)
    qm.material = mat
    g.draw_pass_1 = qm
    geo_root.add_child(g)
    particle_fx.append(g)


func _steam(pos: Vector3) -> void:
    var g := GPUParticles3D.new()
    g.amount = 28
    g.lifetime = 4.0
    g.preprocess = 4.0
    g.local_coords = false
    g.position = pos
    g.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    g.visibility_aabb = AABB(Vector3(-3.0, -3.0, -3.0), Vector3(6.0, 6.0, 6.0))
    var pm := ParticleProcessMaterial.new()
    pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
    pm.emission_sphere_radius = 0.06
    pm.direction = Vector3(0.0, 0.4, 0.0)
    pm.spread = 25.0
    pm.initial_velocity_min = 0.25
    pm.initial_velocity_max = 0.6
    pm.gravity = Vector3(0.0, 0.05, 0.0)
    pm.damping_min = 0.1
    pm.damping_max = 0.3
    pm.scale_min = 0.5
    pm.scale_max = 1.5
    var grad := Gradient.new()
    grad.set_color(0, Color(1, 1, 1, 0.0))
    grad.set_color(1, Color(1, 1, 1, 0.0))
    grad.add_point(0.25, Color(1, 1, 1, 0.8))
    var gt := GradientTexture1D.new()
    gt.gradient = grad
    pm.color_ramp = gt
    var sc := Curve.new()
    sc.add_point(Vector2(0.0, 0.4))
    sc.add_point(Vector2(1.0, 2.6))
    var sct := CurveTexture.new()
    sct.curve = sc
    pm.scale_curve = sct
    g.process_material = pm
    var qm := QuadMesh.new()
    qm.size = Vector2(0.9, 0.9)
    var soft := GradientTexture2D.new()
    var sg := Gradient.new()
    sg.set_color(0, Color(1, 1, 1, 1))
    sg.set_color(1, Color(1, 1, 1, 0))
    soft.gradient = sg
    soft.fill = GradientTexture2D.FILL_RADIAL
    soft.fill_from = Vector2(0.5, 0.5)
    soft.fill_to = Vector2(0.5, 0.0)
    soft.width = 128
    soft.height = 128
    var mat := StandardMaterial3D.new()
    mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.vertex_color_use_as_albedo = true
    mat.albedo_texture = soft
    mat.albedo_color = Color(0.7, 0.75, 0.8, 0.07)
    mat.roughness = 1.0
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mat.proximity_fade_enabled = true
    mat.proximity_fade_distance = 0.4
    qm.material = mat
    g.draw_pass_1 = qm
    geo_root.add_child(g)
    particle_fx.append(g)


func _fog_volume(pos: Vector3, size: Vector3, albedo: Color, density: float) -> void:
    var fv := FogVolume.new()
    fv.position = pos
    fv.size = size
    var fm := FogMaterial.new()
    fm.density = density
    fm.albedo = albedo
    fm.edge_fade = 0.3
    fv.material = fm
    geo_root.add_child(fv)
    fog_volumes.append(fv)


# Reflection probes: give the wet floor, metal and glass something real to reflect.
func _build_probes() -> void:
    var spots: Array = [
        [Vector3(-6.0, 1.5, 0.0), Vector3(9.0, 3.0, 7.5)],
        [Vector3(6.0, 1.5, 0.0), Vector3(14.0, 3.0, 3.8)],
        [Vector3(20.0, 1.5, 0.0), Vector3(14.0, 3.0, 3.8)],
        [Vector3(34.0, 1.5, 0.0), Vector3(14.0, 3.0, 3.8)],
        [Vector3(48.0, 1.5, 0.0), Vector3(14.0, 3.0, 3.8)],
        [Vector3(6.0, 1.5, -6.0), Vector3(7.8, 3.0, 7.8)],
        [Vector3(6.0, 1.5, 6.0), Vector3(7.8, 3.0, 7.8)],
        [Vector3(19.0, 1.5, -6.0), Vector3(9.8, 3.0, 7.8)],
        [Vector3(21.0, 1.5, 8.0), Vector3(13.8, 3.0, 11.8)],
    ]
    for sp in spots:
        var pr := ReflectionProbe.new()
        pr.position = sp[0]
        pr.size = sp[1]
        pr.interior = true
        pr.box_projection = true
        pr.enable_shadows = false
        pr.update_mode = ReflectionProbe.UPDATE_ONCE
        pr.intensity = 0.8
        pr.max_distance = 20.0
        geo_root.add_child(pr)


# =====================================================================
#  DOORS
# =====================================================================

func _make_door(id: String, pos: Vector3, size: Vector3, slide: Vector3, locked: bool, msg: String) -> void:
    var body = _solid(pos, size, m_door, InteractableScript.new())
    body.prompt = "Door (locked)" if locked else "Open door"
    body.on_interact = _on_door.bind(id)
    door_info[id] = {"body": body, "slide": slide, "locked": locked, "open": false, "msg": msg}


func _door_frame(cx: float, z: float, face: float) -> void:
    var zz: float = z + face * 0.17
    _deco(Vector3(cx - 1.05, 1.3, zz), Vector3(0.1, 2.6, 0.06), m_metal)
    _deco(Vector3(cx + 1.05, 1.3, zz), Vector3(0.1, 2.6, 0.06), m_metal)
    _deco(Vector3(cx, 2.63, zz), Vector3(2.2, 0.1, 0.06), m_metal)


func _decal(pos: Vector3, size: Vector3, rot_deg: Vector3, tex: Texture2D, alpha: float) -> void:
    var d := Decal.new()
    d.texture_albedo = tex
    d.size = size
    d.position = pos
    d.rotation_degrees = rot_deg
    d.modulate = Color(1.0, 1.0, 1.0, alpha)
    geo_root.add_child(d)


func _build_decals() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 99
    var blotch: Texture2D = TexGen.get_decal("blotch")
    var streak: Texture2D = TexGen.get_decal("streak")
    var crack: Texture2D = TexGen.get_decal("crack")
    var damp: Texture2D = TexGen.get_decal("damp")
    # cracks in the plaster (positions avoid the door gaps)
    for x in [1.0, 4.2, 10.5, 13.0, 16.5, 22.0, 27.0, 31.0, 35.5, 40.0, 44.0, 48.0, 51.5, 54.0]:
        _decal(Vector3(x + rng.randf_range(-0.3, 0.3), 1.5, -1.6), Vector3(rng.randf_range(0.9, 1.6), 0.7, rng.randf_range(1.6, 2.6)), Vector3(90.0, 0.0, rng.randf_range(-20.0, 20.0)), crack, rng.randf_range(0.7, 1.0))
        _decal(Vector3(x + rng.randf_range(-0.3, 0.3) + 1.6, 1.5, 1.6), Vector3(rng.randf_range(0.9, 1.6), 0.7, rng.randf_range(1.6, 2.6)), Vector3(-90.0, 0.0, rng.randf_range(-20.0, 20.0)), crack, rng.randf_range(0.7, 1.0))
    # damp creeping up from the floor along both walls
    for i in 12:
        var dx: float = rng.randf_range(0.0, 54.0)
        _decal(Vector3(dx, 0.3, -1.45), Vector3(rng.randf_range(1.6, 3.0), 1.0, 0.9), Vector3.ZERO, damp, rng.randf_range(0.6, 1.0))
        _decal(Vector3(dx + rng.randf_range(-3.0, 3.0), 0.3, 1.45), Vector3(rng.randf_range(1.6, 3.0), 1.0, 0.9), Vector3.ZERO, damp, rng.randf_range(0.6, 1.0))
    # grime on the corridor floor (kept away from the walls)
    for i in 16:
        var s: float = rng.randf_range(1.0, 1.6)
        _decal(Vector3(rng.randf_range(0.0, 54.0), 0.3, rng.randf_range(-0.9, 0.9)), Vector3(rng.randf_range(1.2, 2.6), 1.0, s), Vector3.ZERO, blotch, rng.randf_range(0.5, 0.9))
    # stains inside rooms
    for p in [Vector3(-6.0, 0.3, 0.0), Vector3(6.0, 0.3, -6.0), Vector3(6.0, 0.3, 5.5), Vector3(19.0, 0.3, -6.0), Vector3(21.0, 0.3, 7.0), Vector3(22.0, 0.3, 10.0)]:
        _decal(p, Vector3(2.4, 1.0, 2.4), Vector3.ZERO, blotch, 0.8)
    # drip streaks down the corridor walls (x positions avoid the door gaps)
    for x in [1.5, 3.8, 9.5, 12.0, 15.5, 23.0, 25.5, 29.0, 33.0, 37.0, 41.0, 45.0, 49.0, 52.5]:
        _decal(Vector3(x + rng.randf_range(-0.4, 0.4), 1.6, -1.6), Vector3(rng.randf_range(0.8, 1.4), 0.7, 2.8), Vector3(90.0, 0.0, 0.0), streak, rng.randf_range(0.5, 0.85))
        _decal(Vector3(x + rng.randf_range(-0.4, 0.4) + 1.2, 1.6, 1.6), Vector3(rng.randf_range(0.8, 1.4), 0.7, 2.8), Vector3(-90.0, 0.0, 0.0), streak, rng.randf_range(0.5, 0.85))


func _build_doors() -> void:
    _door_frame(6.0, -2.0, 1.0)
    _door_frame(19.0, -2.0, 1.0)
    _door_frame(6.0, 2.0, -1.0)
    _door_frame(20.0, 2.0, -1.0)
    _make_door("security", Vector3(6.0, 1.3, -2.0), Vector3(2.0, 2.6, 0.12), Vector3(1.9, 0, 0), false, "")
    _make_door("power", Vector3(19.0, 1.3, -2.0), Vector3(2.0, 2.6, 0.12), Vector3(1.9, 0, 0), false, "")
    _make_door("storage", Vector3(6.0, 1.3, 2.0), Vector3(2.0, 2.6, 0.12), Vector3(1.9, 0, 0), false, "")
    _make_door("lab", Vector3(20.0, 1.3, 2.0), Vector3(2.0, 2.6, 0.12), Vector3(1.9, 0, 0), true, "The lab door is dead. It needs main power.")

    exit_body = _solid(Vector3(56.0, 1.3, 0.0), Vector3(0.12, 2.6, 2.4), m_door, InteractableScript.new())
    exit_body.prompt = "Main security door"
    exit_body.on_interact = _on_exit


func _on_door(_p, id: String) -> void:
    var info: Dictionary = door_info[id]
    if info["open"]:
        return
    var body = info["body"]
    if info["locked"]:
        hud.show_message(String(info["msg"]), 3.5)
        AudioBank.play_at(self, "locked", body.global_position, 0.0)
        return
    _open_door(id)


func _open_door(id: String) -> void:
    var info: Dictionary = door_info[id]
    info["open"] = true
    var body = info["body"]
    body.enabled = false
    body.collision_layer = 0
    AudioBank.play_at(self, "door", body.global_position, 2.0)
    var slide: Vector3 = info["slide"]
    var tw := create_tween()
    tw.tween_property(body, "position", body.position + slide, 1.1).set_trans(Tween.TRANS_SINE)


func _on_exit(_p) -> void:
    if exit_open:
        return
    if GameManager.fragments < 3 or not GameManager.power_restored:
        hud.show_message("The door needs all 3 access fragments and restored power. (%d/3)" % GameManager.fragments, 4.0)
        AudioBank.play_at(self, "locked", exit_body.global_position, 0.0)
        return
    exit_open = true
    exit_body.enabled = false
    exit_body.collision_layer = 0
    AudioBank.play_at(self, "door", exit_body.global_position, 4.0)
    var tw := create_tween()
    tw.tween_property(exit_body, "position", exit_body.position + Vector3(0.0, 0.0, 2.3), 1.4).set_trans(Tween.TRANS_SINE)
    exit_light.light_energy = 5.0
    hud.show_message("The exit is open. Go.", 4.0)
    _update_objective()


# =====================================================================
#  PROPS AND INTERACTABLES
# =====================================================================

func _note(pos: Vector3, data: Array) -> void:
    var body = _solid(pos, Vector3(0.3, 0.03, 0.22), m_paper, InteractableScript.new())
    body.prompt = "Read"
    body.on_interact = _on_note.bind(String(data[0]), String(data[1]))


func _make_fragment(id: String, pos: Vector3) -> void:
    var body = InteractableScript.new()
    body.position = pos
    body.prompt = "Take access fragment"
    var cs := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(0.5, 0.5, 0.5)
    cs.shape = shape
    body.add_child(cs)
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(0.16, 0.3, 0.05)
    bm.material = m_fragment
    mi.mesh = bm
    mi.rotation_degrees = Vector3(0.0, 0.0, 20.0)
    body.add_child(mi)
    var gl := OmniLight3D.new()
    gl.light_color = Color(1.0, 0.7, 0.25)
    gl.light_energy = 0.9
    gl.omni_range = 3.5
    body.add_child(gl)
    body.on_interact = _collect_fragment.bind(id, body)
    geo_root.add_child(body)
    fragment_meshes.append(mi)


func _make_fuse(pos: Vector3) -> void:
    # A physical, pick-up-able maintenance fuse. Its silhouette and glow make it
    # readable in the flashlight without looking like a floating quest marker.
    fuse_body = InteractableScript.new()
    fuse_body.name = "MaintenanceFuse"
    fuse_body.position = pos
    fuse_body.prompt = "Pick up maintenance fuse"
    var cs := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(0.55, 0.45, 0.55)
    cs.shape = shape
    fuse_body.add_child(cs)
    var casing := MeshInstance3D.new()
    var casing_mesh := BoxMesh.new()
    casing_mesh.size = Vector3(0.34, 0.16, 0.16)
    casing_mesh.material = m_metal
    casing.mesh = casing_mesh
    fuse_body.add_child(casing)
    var cap := MeshInstance3D.new()
    var cap_mesh := CylinderMesh.new()
    cap_mesh.top_radius = 0.065
    cap_mesh.bottom_radius = 0.065
    cap_mesh.height = 0.19
    cap_mesh.material = m_red
    cap.mesh = cap_mesh
    cap.rotation_degrees.z = 90.0
    cap.position.x = 0.19
    fuse_body.add_child(cap)
    var indicator := OmniLight3D.new()
    indicator.light_color = Color(1.0, 0.18, 0.08)
    indicator.light_energy = 0.28
    indicator.omni_range = 1.2
    fuse_body.add_child(indicator)
    fuse_body.on_interact = _collect_fuse
    geo_root.add_child(fuse_body)


func _collect_fuse(_p) -> void:
    if fuse_collected:
        return
    fuse_collected = true
    AudioBank.play_ui(self, "pickup", -1.0)
    if is_instance_valid(fuse_body):
        fuse_body.queue_free()
    hud.show_message("Maintenance fuse secured. Return to the Power Room.", 4.0)
    _update_objective()


func _build_props() -> void:
    # ---- Start room (Bay 0) ----
    _solid(Vector3(-8.5, 0.3, 2.6), Vector3(1.0, 0.6, 2.2), m_metal)               # cot
    _solid(Vector3(-8.8, 0.45, -3.0), Vector3(1.8, 0.9, 0.8), m_wood)              # desk
    _deco(Vector3(-9.4, 1.0, -3.0), Vector3(0.4, 0.2, 0.2), m_screen)              # radio
    _solid(Vector3(-3.0, 1.0, -3.4), Vector3(0.8, 2.0, 0.5), m_metal)              # locker
    _note(Vector3(-8.2, 0.915, -3.0), Story.note_start())

    # ---- Security office ----
    _solid(Vector3(6.0, 0.45, -8.6), Vector3(2.6, 0.9, 0.9), m_wood)               # desk
    for sx in [4.0, 6.0, 8.0]:
        _deco(Vector3(sx, 1.6, -9.8), Vector3(1.0, 0.6, 0.08), m_screen)           # monitors
    _solid(Vector3(3.0, 0.7, -3.2), Vector3(0.7, 1.4, 0.6), m_metal)               # cabinets
    _solid(Vector3(9.0, 0.7, -3.2), Vector3(0.7, 1.4, 0.6), m_metal)
    _note(Vector3(5.0, 0.915, -8.6), Story.note_security())
    _make_fragment("security", Vector3(7.0, 1.25, -8.6))

    # ---- Storage room ----
    _solid(Vector3(3.5, 0.5, 4.0), Vector3(1.2, 1.0, 1.2), m_crate)
    _solid(Vector3(8.5, 0.5, 3.8), Vector3(1.4, 1.0, 1.0), m_crate)
    _solid(Vector3(3.6, 0.5, 7.5), Vector3(1.2, 1.0, 1.2), m_crate)
    _solid(Vector3(3.6, 1.4, 7.5), Vector3(0.9, 0.8, 0.9), m_crate)
    _solid(Vector3(6.0, 0.5, 6.0), Vector3(1.0, 1.0, 1.0), m_crate)
    _solid(Vector3(8.5, 0.5, 9.0), Vector3(1.3, 1.0, 1.3), m_crate)                # Crate 15
    _make_fuse(Vector3(7.2, 1.12, 5.9))
    _solid(Vector3(9.6, 1.0, 6.5), Vector3(0.6, 2.0, 2.5), m_metal)                # shelf
    _note(Vector3(3.5, 1.015, 4.0), Story.note_storage())
    _make_fragment("storage", Vector3(8.5, 1.35, 9.0))

    # ---- Power room ----
    _cyl(Vector3(16.0, 1.0, -8.5), 0.8, 2.0, m_metal)
    _cyl(Vector3(22.0, 1.0, -8.5), 0.8, 2.0, m_metal)
    _cyl(Vector3(19.0, 2.6, -9.6), 0.12, 10.0, m_metal, true, false)
    console_body = _solid(Vector3(19.0, 0.55, -9.0), Vector3(3.2, 1.1, 0.9), m_metal, InteractableScript.new())
    console_body.prompt = "Use power console"
    console_body.on_interact = _on_console
    var screen := _deco(Vector3(19.0, 1.5, -9.4), Vector3(2.6, 0.7, 0.08), console_screen_mat)
    screen.rotation_degrees = Vector3(0.0, 0.0, 0.0)
    _solid(Vector3(15.0, 0.35, -3.2), Vector3(0.8, 0.7, 0.5), m_crate)
    _note(Vector3(15.0, 0.715, -3.2), Story.note_power())

    # ---- Research lab ----
    _solid(Vector3(18.0, 0.5, 5.5), Vector3(3.0, 1.0, 1.1), m_metal)
    _solid(Vector3(24.0, 0.5, 5.5), Vector3(3.0, 1.0, 1.1), m_metal)
    _note(Vector3(18.0, 1.015, 5.5), Story.note_lab())
    var rec = _solid(Vector3(24.0, 1.04, 5.5), Vector3(0.3, 0.08, 0.2), m_screen, InteractableScript.new())
    rec.prompt = "Play recording"
    rec.on_interact = _on_note.bind(String(Story.recording()[0]), String(Story.recording()[1]))
    for tz in [8.0, 10.5]:
        _cyl(Vector3(15.2, 1.3, tz), 0.45, 2.6, m_glass)
        _cyl(Vector3(26.8, 1.3, tz), 0.45, 2.6, m_glass)
    _solid(Vector3(21.0, 0.45, 12.2), Vector3(1.4, 0.9, 1.4), m_metal)             # pedestal
    _make_fragment("lab", Vector3(21.0, 1.3, 12.2))

    # ---- Locker row (start room) ----
    for lx in [-6.5, -5.9, -5.3, -4.7]:
        _solid(Vector3(lx, 1.0, -3.6), Vector3(0.58, 2.0, 0.5), m_metal)
        _deco(Vector3(lx, 1.3, -3.34), Vector3(0.4, 0.9, 0.02), m_dark)

    # ---- Wheelchair (start room) ----
    _wheelchair(Vector3(-4.5, 0.0, 2.6), 0.5)

    # ---- Medical carts in the corridor and storage ----
    _cart(Vector3(13.5, 0.0, -1.25))
    _cart(Vector3(29.0, 0.0, 1.25))
    _cart(Vector3(7.5, 0.0, 8.2))
    _wheelchair(Vector3(26.0, 0.0, 12.0), -0.6)
    for lz in [3.5, 4.1, 4.7]:
        _solid(Vector3(27.6, 1.0, lz), Vector3(0.5, 2.0, 0.58), m_metal)

    # ---- Final corridor clutter (kept to the sides so the path stays clear) ----
    _solid(Vector3(38.0, 0.4, -1.4), Vector3(1.4, 0.8, 0.6), m_metal)
    _solid(Vector3(46.0, 0.4, 1.4), Vector3(0.9, 0.8, 0.9), m_crate)
    _solid(Vector3(51.0, 0.6, -1.4), Vector3(0.8, 1.2, 0.5), m_metal)

    # ---- Exit courtyard floor marker ----
    _deco(Vector3(60.0, 0.01, 0.0), Vector3(6.0, 0.02, 3.0), _glow(Color(0.3, 0.4, 0.5), 0.4))


func _cart(pos: Vector3) -> void:
    _solid(pos + Vector3(0.0, 0.45, 0.0), Vector3(1.2, 0.9, 0.6), m_metal)
    _deco(pos + Vector3(-0.3, 1.02, 0.0), Vector3(0.45, 0.24, 0.4), m_crate)
    _deco(pos + Vector3(0.25, 1.0, 0.05), Vector3(0.35, 0.2, 0.3), m_paper)


func _wheelchair(pos: Vector3, yaw: float) -> void:
    var root := Node3D.new()
    root.position = pos
    root.rotation.y = yaw
    geo_root.add_child(root)
    var body := StaticBody3D.new()
    root.add_child(body)
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(0.7, 0.9, 0.6)
    cs.shape = bs
    cs.position = Vector3(0.0, 0.45, 0.0)
    body.add_child(cs)
    var parts: Array = [
        [Vector3(0.0, 0.5, 0.0), Vector3(0.5, 0.08, 0.5)],
        [Vector3(0.0, 0.85, 0.22), Vector3(0.5, 0.6, 0.05)],
        [Vector3(0.0, 0.3, -0.2), Vector3(0.4, 0.04, 0.04)],
    ]
    for p in parts:
        var mi := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = p[1]
        bm.material = m_dark
        mi.mesh = bm
        mi.position = p[0]
        root.add_child(mi)
    for sx in [-0.3, 0.3]:
        var w := MeshInstance3D.new()
        var cm := CylinderMesh.new()
        cm.top_radius = 0.3
        cm.bottom_radius = 0.3
        cm.height = 0.04
        cm.material = m_dark
        w.mesh = cm
        w.position = Vector3(sx, 0.3, 0.1)
        w.rotation_degrees = Vector3(0.0, 0.0, 90.0)
        root.add_child(w)


func _build_debris() -> void:
    # Paper sheets and glossy puddles scattered on the floor (no collision).
    var rng := RandomNumberGenerator.new()
    rng.seed = 1234
    var zones: Array = [
        [0.0, 54.0, -1.7, 1.7, 55],
        [-9.5, -2.5, -3.5, 3.5, 12],
        [3.0, 9.0, -9.0, -3.0, 8],
        [3.0, 9.0, 3.0, 9.0, 8],
        [15.0, 27.0, 3.0, 13.0, 12],
    ]
    for z in zones:
        for i in int(z[4]):
            var pos := Vector3(rng.randf_range(z[0], z[1]), 0.004 + rng.randf() * 0.003, rng.randf_range(z[2], z[3]))
            var mi := MeshInstance3D.new()
            var bm := BoxMesh.new()
            bm.size = Vector3(0.21, 0.004, 0.3)
            bm.material = m_sheet
            mi.mesh = bm
            mi.position = pos
            mi.rotation_degrees = Vector3(rng.randf_range(-2.0, 2.0), rng.randf_range(0.0, 360.0), rng.randf_range(-2.0, 2.0))
            geo_root.add_child(mi)
    for i in 26:
        var sz := Vector3(rng.randf_range(0.6, 1.8), 0.008, rng.randf_range(0.5, 1.4))
        var pp := Vector3(rng.randf_range(0.0, 54.0), 0.006, rng.randf_range(-1.5, 1.5))
        _deco(pp, sz, m_puddle)


func _on_note(_p, title: String, body_text: String) -> void:
    if GameManager.note_open:
        return
    GameManager.note_open = true
    GameManager.notes_read += 1
    note_opened_at = Time.get_ticks_msec()
    player.frozen = true
    hud.show_note(title, body_text)
    AudioBank.play_ui(self, "paper", -4.0)
    if title.begins_with("RECORDING"):
        AudioBank.play_ui(self, "static", -10.0)
    _update_objective()


func _close_note() -> void:
    if not GameManager.note_open:
        return
    GameManager.note_open = false
    hud.hide_note()
    if not catching:
        player.frozen = false


func _on_console(_p) -> void:
    if GameManager.power_restored:
        hud.show_message("Power is already restored.", 2.5)
        return
    if GameManager.fragments < 2:
        hud.show_message("The console needs two access fragments. (%d/2)" % GameManager.fragments, 4.0)
        AudioBank.play_at(self, "locked", console_body.global_position, 0.0)
        return
    if not fuse_collected:
        hud.show_message("The power circuit is incomplete. Find a maintenance fuse in Storage.", 4.0)
        AudioBank.play_at(self, "locked", console_body.global_position, 0.0)
        return
    GameManager.power_restored = true
    console_body.enabled = false
    console_screen_mat.emission = Color(0.2, 1.0, 0.4)
    door_info["lab"]["locked"] = false
    door_info["lab"]["body"].prompt = "Open door"
    director.on_power()
    _update_objective()


func _collect_fragment(_p, id: String, body) -> void:
    GameManager.add_fragment()
    AudioBank.play_ui(self, "pickup", -2.0)
    body.queue_free()
    var n: int = GameManager.fragments
    hud.show_message("Access fragment acquired (%d/3)" % n, 4.0)
    director.on_fragment(n, id)
    if id == "lab":
        _start_chase()
    _update_objective()


# =====================================================================
#  LIGHTS
# =====================================================================

func _add_light(pos: Vector3, color: Color, em: float, pw: float, rng: float, group: String) -> void:
    var l = FlickerLightScript.new()
    l.position = pos
    l.light_color = color
    l.omni_range = rng
    l.shadow_enabled = not GameManager.low_spec
    l.shadow_blur = 1.6
    l.omni_attenuation = 1.25
    l.light_volumetric_fog_energy = 1.0
    l.group = group
    l.hum = {"corridor": 0.7, "room": 0.35, "final": 0.25, "exit": 0.0}.get(group, 0.3)
    l.emergency_energy = em
    l.powered_energy = pw
    var fm := StandardMaterial3D.new()
    fm.albedo_color = Color(0.8, 0.85, 0.9)
    fm.emission_enabled = true
    fm.emission = color
    fm.emission_energy_multiplier = 2.0
    l.fixture_mat = fm
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(1.0, 0.06, 0.22)
    mi.mesh = bm
    mi.material_override = fm
    mi.position = Vector3(0.0, 0.17, 0.0)
    l.add_child(mi)
    var hs := MeshInstance3D.new()
    var hb := BoxMesh.new()
    hb.size = Vector3(1.16, 0.1, 0.32)
    hs.mesh = hb
    hs.material_override = m_dark
    hs.position = Vector3(0.0, 0.22, 0.0)
    l.add_child(hs)
    geo_root.add_child(l)
    l.set_power(false)
    lights.append(l)


func _add_spot(pos: Vector3, color: Color, energy: float, angle: float) -> void:
    var s := SpotLight3D.new()
    s.position = pos
    s.rotation_degrees = Vector3(-90.0, 0.0, 0.0)
    s.light_color = color
    s.light_energy = energy
    s.spot_range = 6.0
    s.spot_angle = angle
    geo_root.add_child(s)


func _build_lights() -> void:
    var cool := Color(0.7, 0.82, 1.0)
    var red := Color(1.0, 0.3, 0.25)
    # corridor (some are dead until power returns)
    _add_light(Vector3(2.0, 2.8, 0.0), cool, 0.5, 1.2, 9.5, "corridor")
    _add_light(Vector3(10.0, 2.8, 0.0), cool, 0.0, 1.2, 9.5, "corridor")
    _add_light(Vector3(18.0, 2.8, 0.0), cool, 0.45, 1.2, 9.5, "corridor")
    _add_light(Vector3(26.0, 2.8, 0.0), cool, 0.0, 1.2, 9.5, "corridor")
    # final escape corridor: red emergency strips
    _add_light(Vector3(34.0, 2.8, 0.0), red, 0.6, 0.9, 9.5, "final")
    _add_light(Vector3(42.0, 2.8, 0.0), red, 0.5, 0.9, 9.5, "final")
    _add_light(Vector3(50.0, 2.8, 0.0), red, 0.6, 0.9, 9.5, "final")
    # rooms
    _add_light(Vector3(-6.0, 2.8, 0.0), Color(1.0, 0.85, 0.65), 0.5, 1.0, 8.0, "room")
    _add_light(Vector3(6.0, 2.8, -6.0), cool, 0.45, 1.0, 8.0, "room")
    _add_light(Vector3(6.0, 2.8, 6.0), cool, 0.3, 0.9, 8.0, "room")
    _add_light(Vector3(19.0, 2.8, -6.0), Color(1.0, 0.6, 0.4), 0.5, 1.0, 9.0, "room")
    _add_light(Vector3(21.0, 2.8, 8.0), Color(0.4, 1.0, 0.9), 0.0, 1.0, 10.0, "room")
    # exit guide light (always on, never dimmed)
    _add_light(Vector3(54.0, 2.8, 0.0), Color(0.4, 1.0, 0.5), 0.8, 0.8, 7.0, "exit")

    _add_spot(Vector3(19.0, 2.9, -7.0), Color(1.0, 0.7, 0.5), 3.0, 40.0)
    _add_spot(Vector3(21.0, 2.9, 11.5), Color(0.8, 1.0, 1.0), 3.5, 35.0)

    exit_light = OmniLight3D.new()
    exit_light.position = Vector3(60.0, 2.2, 0.0)
    exit_light.light_color = Color(0.8, 0.9, 1.0)
    exit_light.light_energy = 0.0
    exit_light.omni_range = 14.0
    geo_root.add_child(exit_light)


# =====================================================================
#  ACTORS / UI / DIRECTOR
# =====================================================================

func _spawn_player() -> void:
    player = PlayerScript.new()
    player.position = Vector3(-6.0, 0.1, 0.0)
    player.rotation.y = -PI / 2.0
    add_child(player)


func _spawn_watcher() -> void:
    watcher = WatcherScript.new()
    watcher.player = player
    add_child(watcher)
    watcher.caught_player.connect(_on_caught)


func _build_ui() -> void:
    postfx = PostFxScript.new()
    add_child(postfx)
    hud = HudScript.new()
    add_child(hud)
    pause_menu = PauseScript.new()
    add_child(pause_menu)
    player.prompt_changed.connect(hud.set_prompt)
    watcher.observed_changed.connect(hud.set_gaze)
    GameManager.fragments_changed.connect(hud.set_fragments)
    hud.restart_requested.connect(_restart)
    hud.menu_requested.connect(_to_menu)
    pause_menu.restart_requested.connect(_restart)
    pause_menu.menu_requested.connect(_to_menu)


func _build_director() -> void:
    director = DirectorScript.new()
    add_child(director)
    director.setup(self, player, watcher, hud, lights)


func _restart() -> void:
    get_tree().paused = false
    get_tree().reload_current_scene()


func _to_menu() -> void:
    get_tree().paused = false
    get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


# =====================================================================
#  FLOW: intro, objectives, chase, caught, ending
# =====================================================================

func _intro() -> void:
    player.frozen = true
    hud.set_black()
    hud.fade(0.0, 3.0)
    var t := create_tween()
    t.tween_interval(1.6)
    t.tween_callback(_intro_done)


func _intro_done() -> void:
    player.frozen = false
    hud.show_message("WASD move  |  Shift run  |  Ctrl crouch  |  F flashlight  |  E pick up / interact  |  Esc pause. Explore rooms for fragments and a fuse.", 8.0)


func _update_objective() -> void:
    var t: String = ""
    if exit_open:
        t = "Leave the facility."
    elif chase_on:
        t = "RUN. Reach the main exit at the east end of the corridor. Looking at it freezes it."
    elif GameManager.power_restored:
        t = "Power restored. Enter the Research Lab (south side of the corridor) and take the third fragment."
    elif GameManager.fragments >= 2 and not fuse_collected:
        t = "Find the maintenance fuse in the Storage Room, then return to the Power Room console."
    elif GameManager.fragments >= 2:
        t = "Restore power at the console in the Power Room (north side of the corridor)."
    elif GameManager.notes_read == 0 and GameManager.fragments == 0:
        t = "Read the log on the desk, then head east into the corridor."
    else:
        t = "Explore the side rooms. Collect access fragments (%d/3), read notes, and search Storage for a fuse." % GameManager.fragments
    hud.set_objective(t)


func _start_chase() -> void:
    chase_on = true
    checkpoint = Vector3(22.0, 0.1, 0.0)
    director.start_chase()


func _on_caught() -> void:
    if catching or ending_started:
        return
    catching = true
    GameManager.times_caught += 1
    player.frozen = true
    AudioBank.play_ui(self, "caught", 0.0)
    player.add_shake(0.06)
    var tw: Tween = hud.fade(1.0, 0.45)
    tw.tween_interval(0.3)
    tw.tween_callback(_after_caught_black)


func _after_caught_black() -> void:
    if GameManager.note_open:
        GameManager.note_open = false
        hud.hide_note()
    player.teleport(checkpoint, -PI / 2.0)
    watcher.speed = maxf(3.8, 5.0 - 0.4 * float(GameManager.times_caught))
    director.reset_chase(checkpoint.x - 17.0)
    hud.show_message("It caught you. The facility lets you try again.", 3.5)
    var tw: Tween = hud.fade(0.0, 0.8)
    tw.tween_callback(_after_caught_clear)


func _after_caught_clear() -> void:
    player.frozen = false
    catching = false


func _begin_ending() -> void:
    ending_started = true
    GameManager.can_pause = false
    player.frozen = true
    director.set_phase("ended")
    var tw: Tween = hud.fade(1.0, 2.5)
    tw.tween_callback(_show_ending_ui)


func _show_ending_ui() -> void:
    watcher.hide_watcher()
    var data: Array
    if GameManager.longest_gaze >= 3.0:
        data = Story.ending_good()
    else:
        data = Story.ending_loop()
    hud.show_ending(String(data[0]), String(data[1]))


# =====================================================================
#  PER-FRAME / INPUT
# =====================================================================

func _process(delta: float) -> void:
    for f in fragment_meshes:
        if is_instance_valid(f):
            f.rotate_y(delta * 1.5)
    if player == null or hud == null:
        return
    var s: float = player.stamina / player.max_stamina
    var b: float = player.battery / player.max_battery
    hud.set_bars(s, b)

    var st: float = 0.0
    if chase_on and watcher != null and watcher.visible:
        st = clampf(1.0 - watcher.global_position.distance_to(player.global_position) / 30.0, 0.0, 1.0)
    _stress = lerpf(_stress, st, minf(delta * 3.0, 1.0))
    if postfx != null:
        postfx.set_stress(_stress)

    var px: float = player.global_position.x
    if chase_on and not exit_open and px > 44.0 and checkpoint.x < 44.0:
        checkpoint = Vector3(44.0, 0.1, 0.0)
    if exit_open and not ending_started and px > 59.0:
        _begin_ending()


func _unhandled_input(event: InputEvent) -> void:
    if not GameManager.note_open:
        return
    var close: bool = false
    if event.is_action_pressed("interact") or event.is_action_pressed("ui_cancel"):
        close = true
    elif event is InputEventMouseButton and event.is_pressed():
        close = true
    if close and Time.get_ticks_msec() - note_opened_at > 250:
        get_viewport().set_input_as_handled()
        call_deferred("_close_note")

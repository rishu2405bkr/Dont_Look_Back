extends Node
# State-based Horror Director. Phases: "explore", "chase", "ended".
# Everything is telegraphed with sound first and nothing here can hurt the player.
# Only the chase (see watcher.gd) can "catch" you, and that just resets you to a checkpoint.

const AudioBank = preload("res://scripts/audio_bank.gd")

const IDLE_RADIO: Array = [
    "[RADIO] ...still there?...",
    "[RADIO] ...keep your eyes open...",
    "[RADIO] ...it only moves when you are not looking...",
    "[RADIO] ...three fragments... keep going...",
    "[RADIO] ...behind you...",
]

var level
var player
var watcher
var hud
var lights: Array = []

var phase: String = "explore"
var event_timer: float = 28.0
var event_min: float = 18.0
var event_max: float = 34.0
var last_event: String = ""

var apparition_active: bool = false
var apparition_pos: Vector3 = Vector3.ZERO
var apparition_age: float = 0.0
var apparition_seen: float = 0.0

var flicker_timer: float = 1.5
var drone: AudioStreamPlayer
var heartbeat: AudioStreamPlayer
var _jobs: Array = []


func setup(p_level, p_player, p_watcher, p_hud, p_lights: Array) -> void:
    level = p_level
    player = p_player
    watcher = p_watcher
    hud = p_hud
    lights = p_lights

    drone = AudioStreamPlayer.new()
    drone.stream = AudioBank.get_sound("drone")
    drone.volume_db = -20.0 + GameManager.audio_offset()
    add_child(drone)
    drone.play()

    heartbeat = AudioStreamPlayer.new()
    heartbeat.stream = AudioBank.get_sound("heartbeat")
    heartbeat.volume_db = -40.0
    add_child(heartbeat)

    after(4.5, _intro_radio)


func after(sec: float, fn: Callable) -> void:
    _jobs.append({"t": sec, "fn": fn})


func radio(text: String, secs: float = 5.0) -> void:
    AudioBank.play_ui(level, "static", -12.0)
    hud.show_message(text, secs)


func _intro_radio() -> void:
    if phase != "explore":
        return
    radio("[RADIO] ...kzzt... Bay Zero... if anyone can hear this... find the three access fragments... and don't look back.", 8.0)


func _process(delta: float) -> void:
    var i: int = 0
    while i < _jobs.size():
        var j: Dictionary = _jobs[i]
        j["t"] = float(j["t"]) - delta
        if float(j["t"]) <= 0.0:
            _jobs.remove_at(i)
            var fn: Callable = j["fn"]
            if fn.is_valid():
                fn.call()
        else:
            i += 1

    if phase == "explore":
        event_timer -= delta
        if event_timer <= 0.0:
            event_timer = randf_range(event_min, event_max)
            _random_event()
        _update_apparition(delta)
    elif phase == "chase":
        _update_chase(delta)


# ---------- scripted hooks (called by the level) ----------

func on_fragment(n: int, id: String) -> void:
    if id == "lab":
        return
    for l in lights:
        if l.global_position.distance_to(player.global_position) < 14.0:
            l.flicker(1.2)
    if n == 1:
        radio("[RADIO] ...one... two more... keep moving...", 5.0)
        after(2.5, _ev_knock)
    elif n == 2:
        radio("[RADIO] ...the console... north side... the power room...", 5.0)
    event_timer = maxf(event_timer, 12.0)


func on_power() -> void:
    AudioBank.play_ui(level, "power", -2.0)
    for l in lights:
        l.set_power(true)
        l.flicker(randf_range(1.0, 2.2))
    radio("[RADIO] Power is back. ...something else just woke up.", 6.0)
    event_min = 12.0
    event_max = 22.0
    event_timer = 8.0


func start_chase() -> void:
    phase = "chase"
    apparition_active = false
    for l in lights:
        if l.group == "corridor":
            l.set_rest(0.14)
            l.flicker(1.5)
    heartbeat.play()
    watcher.speed = 5.0
    watcher.start_chase(Vector3(2.0, 0.0, 0.0), 7.0)
    AudioBank.play_ui(level, "caught", -8.0)
    radio("[RADIO] RUN. The exit is east. Don't... don't look back.", 6.0)


func reset_chase(spawn_x: float) -> void:
    watcher.start_chase(Vector3(maxf(spawn_x, -1.0), 0.0, 0.0), 3.0)


func set_phase(p: String) -> void:
    phase = p
    if p == "ended":
        heartbeat.stop()
        drone.volume_db = -34.0


# ---------- random events (explore phase) ----------

func _random_event() -> void:
    var options: Array = ["footsteps", "knock", "flicker", "static", "apparition"]
    options.erase(last_event)
    var pick: String = options[randi() % options.size()]
    last_event = pick
    match pick:
        "footsteps":
            _ev_footsteps()
        "knock":
            _ev_knock()
        "flicker":
            _ev_flicker()
        "static":
            _ev_static()
        "apparition":
            if not _try_apparition():
                _ev_footsteps()


func _ev_footsteps() -> void:
    for k in 4:
        after(0.65 * float(k), _step_cue.bind(k))


func _step_cue(k: int) -> void:
    if phase != "explore":
        return
    var back: Vector3 = -player.get_forward_flat()
    var pos: Vector3 = player.global_position + back * (13.0 - 2.0 * float(k)) + Vector3(0.0, 0.1, 0.0)
    AudioBank.play_at(level, "footstep", pos, 4.0, randf_range(0.8, 0.95))


func _ev_knock() -> void:
    if phase != "explore":
        return
    var ang: float = randf() * TAU
    var pos: Vector3 = player.global_position + Vector3(cos(ang), 0.0, sin(ang)) * randf_range(6.0, 10.0) + Vector3(0.0, 1.3, 0.0)
    AudioBank.play_at(level, "knock", pos, 3.0)


func _ev_flicker() -> void:
    var pp: Vector3 = player.global_position
    var near: Array = []
    for l in lights:
        if l.global_position.distance_to(pp) < 16.0:
            near.append(l)
    if near.is_empty():
        return
    var pick = near[randi() % near.size()]
    pick.flicker(randf_range(1.0, 2.0))
    AudioBank.play_at(level, "buzz", pick.global_position, 0.0)


func _ev_static() -> void:
    var line: String = IDLE_RADIO[randi() % IDLE_RADIO.size()]
    radio(line, 3.5)


# ---------- apparition: a still silhouette you see only when you turn around ----------

func _try_apparition() -> bool:
    if phase != "explore" or apparition_active:
        return false
    var p: Vector3 = player.global_position
    if p.x < 4.0 or p.x > 28.0 or absf(p.z) > 2.2:
        return false
    var f: Vector3 = player.get_forward_flat()
    if absf(f.x) < 0.5:
        return false
    var sx: float = p.x - signf(f.x) * 12.0
    if sx < 0.0 or sx > 30.0:
        return false
    apparition_pos = Vector3(sx, 0.0, 0.0)
    apparition_active = true
    AudioBank.play_at(level, "footstep", apparition_pos + Vector3(0.0, 0.1, 0.0), 4.0, 0.85)
    after(0.7, _step_apparition_cue)
    after(1.4, _show_apparition)
    return true


func _step_apparition_cue() -> void:
    AudioBank.play_at(level, "footstep", apparition_pos + Vector3(0.0, 0.1, 0.0), 4.0, 0.8)


func _show_apparition() -> void:
    if phase != "explore" or not apparition_active:
        apparition_active = false
        return
    watcher.show_apparition(apparition_pos)
    apparition_age = 0.0
    apparition_seen = 0.0


func _update_apparition(delta: float) -> void:
    if not apparition_active or watcher.mode != "apparition":
        return
    apparition_age += delta
    var d: float = player.global_position.distance_to(watcher.global_position)
    if watcher.observed:
        apparition_seen += delta
    if apparition_seen >= 1.6:
        _end_apparition(true)
    elif apparition_age > 20.0 or d < 6.0:
        _end_apparition(false)


func _end_apparition(seen: bool) -> void:
    apparition_active = false
    var wp: Vector3 = watcher.global_position
    watcher.hide_watcher()
    if seen:
        AudioBank.play_at(level, "buzz", wp + Vector3(0.0, 2.0, 0.0), 2.0)
        for l in lights:
            if l.global_position.distance_to(wp) < 12.0:
                l.flicker(1.0)
        player.add_shake(0.03)


# ---------- chase ----------

func _update_chase(delta: float) -> void:
    var d: float = player.global_position.distance_to(watcher.global_position)
    var closeness: float = clampf(1.0 - d / 16.0, 0.0, 1.0)
    heartbeat.volume_db = lerpf(-32.0, -6.0, closeness) + GameManager.audio_offset()
    heartbeat.pitch_scale = lerpf(0.9, 1.4, closeness)
    flicker_timer -= delta
    if flicker_timer <= 0.0:
        flicker_timer = randf_range(0.8, 2.0)
        var wp: Vector3 = watcher.global_position
        for l in lights:
            if l.group == "corridor" and l.global_position.distance_to(wp) < 10.0:
                l.flicker(0.5)

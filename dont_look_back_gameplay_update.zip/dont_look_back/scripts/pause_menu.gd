extends CanvasLayer
# Pause menu. Works while the tree is paused (process_mode ALWAYS).

signal restart_requested
signal menu_requested

const SettingsPanel = preload("res://scripts/settings_panel.gd")

var main_box: VBoxContainer
var settings_box: VBoxContainer


func _ready() -> void:
    layer = 30
    process_mode = Node.PROCESS_MODE_ALWAYS
    visible = false

    var root := Control.new()
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.78)
    root.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var center := CenterContainer.new()
    root.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 12)
    center.add_child(vb)

    var title := Label.new()
    title.text = "PAUSED"
    title.add_theme_font_size_override("font_size", 48)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(title)

    main_box = VBoxContainer.new()
    main_box.add_theme_constant_override("separation", 10)
    vb.add_child(main_box)
    _button(main_box, "RESUME", close)
    _button(main_box, "SETTINGS", _toggle_settings)
    _button(main_box, "RESTART", _on_restart)
    _button(main_box, "MAIN MENU", _on_menu)
    _button(main_box, "QUIT GAME", _on_quit)

    settings_box = SettingsPanel.new()
    settings_box.visible = false
    vb.add_child(settings_box)


func _button(parent: Control, text: String, cb: Callable) -> void:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(280, 44)
    b.pressed.connect(cb)
    parent.add_child(b)


func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_cancel"):
        if visible:
            close()
            get_viewport().set_input_as_handled()
        elif GameManager.can_pause and not GameManager.note_open:
            open()
            get_viewport().set_input_as_handled()


func open() -> void:
    visible = true
    get_tree().paused = true
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func close() -> void:
    visible = false
    settings_box.visible = false
    get_tree().paused = false
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _toggle_settings() -> void:
    settings_box.visible = not settings_box.visible


func _on_restart() -> void:
    restart_requested.emit()


func _on_menu() -> void:
    menu_requested.emit()


func _on_quit() -> void:
    get_tree().quit()

extends Node3D
# The Watcher. A silhouette that never moves while you are looking at it.
# modes: "hidden", "apparition" (static, harmless), "chase" (advances when unseen).

const AudioBank = preload("res://scripts/audio_bank.gd")
const TexGen = preload("res://scripts/tex_gen.gd")

signal caught_player
signal observed_changed(is_observed: bool)

var mode: String = "hidden"
var player = null
var speed: float = 5.0
var catch_distance: float = 1.3
var observed: bool = false
var gaze_time: float = 0.0
var wait_left: float = 0.0

var body_root: Node3D
var _head_node: Node3D
var _t: float = 0.0
var _step_timer: float = 0.0
var _step_audio: AudioStreamPlayer3D


func _ready() -> void:
    visible = false
    body_root = Node3D.new()
    body_root.scale = Vector3(1.1, 1.1, 1.1)
    add_child(body_root)

    # Lit, wet-looking pale skin (procedural PBR) with a faint emission and rim so it never vanishes in the dark.
    var sk: Dictionary = TexGen.get_set("skin")
    var skin := StandardMaterial3D.new()
    skin.albedo_texture = sk["albedo"]
    skin.normal_enabled = true
    skin.normal_texture = sk["normal"]
    skin.roughness_texture = sk["rough"]
    skin.roughness = 1.0
    skin.ao_enabled = true
    skin.ao_texture = sk["ao"]
    skin.uv1_triplanar = true
    skin.uv1_scale = Vector3(1.6, 1.6, 1.6)
    skin.subsurf_scatter_enabled = true
    skin.subsurf_scatter_strength = 0.35
    skin.rim_enabled = true
    skin.rim = 0.7
    skin.rim_tint = 0.4
    skin.emission_enabled = true
    skin.emission = Color(0.05, 0.06, 0.08)
    skin.emission_energy_multiplier = 1.0

    var cloth := StandardMaterial3D.new()
    cloth.albedo_color = Color(0.17, 0.19, 0.18)
    cloth.roughness = 1.0
    cloth.cull_mode = BaseMaterial3D.CULL_DISABLED
    cloth.rim_enabled = true
    cloth.rim = 0.4

    var hair := StandardMaterial3D.new()
    hair.albedo_color = Color(0.015, 0.014, 0.016)
    hair.roughness = 0.45
    hair.specular_mode = BaseMaterial3D.SPECULAR_SCHLICK_GGX

    var glow := StandardMaterial3D.new()
    glow.albedo_color = Color(0.7, 0.9, 1.0)
    glow.emission_enabled = true
    glow.emission = Color(0.6, 0.85, 1.0)
    glow.emission_energy_multiplier = 3.0
    glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

    # Gaunt, hunched body: ribcage, hospital gown, long neck, arms that hang too far.
    var torso := CapsuleMesh.new()
    torso.radius = 0.15
    torso.height = 0.95
    _add_mesh(torso, skin, Vector3(0.0, 1.15, 0.05), Vector3(18.0, 0.0, 0.0))
    var chest := SphereMesh.new()
    chest.radius = 0.2
    chest.height = 0.36
    _add_mesh(chest, skin, Vector3(0.0, 1.38, -0.0), Vector3(18.0, 0.0, 0.0))
    for rb in 4:
        var rib := CapsuleMesh.new()
        rib.radius = 0.012
        rib.height = 0.3
        _add_mesh(rib, skin, Vector3(0.0, 1.46 - 0.06 * float(rb), -0.15 - 0.005 * float(rb)), Vector3(18.0, 0.0, 90.0))
    var gown := CylinderMesh.new()
    gown.top_radius = 0.2
    gown.bottom_radius = 0.34
    gown.height = 0.85
    gown.radial_segments = 14
    _add_mesh(gown, cloth, Vector3(0.0, 0.78, 0.02), Vector3(4.0, 0.0, 0.0))

    var neck := CylinderMesh.new()
    neck.top_radius = 0.045
    neck.bottom_radius = 0.06
    neck.height = 0.22
    _add_mesh(neck, skin, Vector3(0.0, 1.58, -0.08), Vector3(25.0, 0.0, 0.0))

    _head_node = Node3D.new()
    _head_node.position = Vector3(0.0, 1.68, -0.2)
    _head_node.rotation_degrees = Vector3(25.0, 0.0, 0.0)
    body_root.add_child(_head_node)
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.12
    head_mesh.height = 0.34
    _add_mesh(head_mesh, skin, Vector3.ZERO, Vector3.ZERO, _head_node)
    var jaw := SphereMesh.new()
    jaw.radius = 0.07
    jaw.height = 0.13
    _add_mesh(jaw, skin, Vector3(0.0, -0.15, -0.03), Vector3(-15.0, 0.0, 0.0), _head_node)
    # long, wet hair hanging over the face
    var hr := RandomNumberGenerator.new()
    hr.seed = 5
    for hi in 16:
        var strand := CylinderMesh.new()
        strand.top_radius = 0.006
        strand.bottom_radius = 0.002
        strand.height = hr.randf_range(0.35, 0.7)
        var ang: float = hr.randf_range(-PI, PI)
        var px: float = sin(ang) * 0.11
        var pz: float = cos(ang) * 0.1
        _add_mesh(strand, hair, Vector3(px, 0.07 - strand.height * 0.45, pz - 0.02), Vector3(hr.randf_range(-5.0, 5.0), 0.0, hr.randf_range(-5.0, 5.0)), _head_node)
    var eye := SphereMesh.new()
    eye.radius = 0.02
    eye.height = 0.04
    _add_mesh(eye, glow, Vector3(-0.045, 0.0, -0.105), Vector3.ZERO, _head_node)
    _add_mesh(eye, glow, Vector3(0.045, 0.0, -0.105), Vector3.ZERO, _head_node)
    var eye_light := OmniLight3D.new()
    eye_light.light_color = Color(0.6, 0.85, 1.0)
    eye_light.light_energy = 0.3
    eye_light.omni_range = 2.5
    eye_light.shadow_enabled = false
    eye_light.position = Vector3(0.0, 0.0, -0.15)
    _head_node.add_child(eye_light)

    # arms: upper arm, forearm, hand with long fingers
    for sx in [-1.0, 1.0]:
        var upper := CylinderMesh.new()
        upper.top_radius = 0.04
        upper.bottom_radius = 0.032
        upper.height = 0.55
        _add_mesh(upper, skin, Vector3(0.27 * sx, 1.15, -0.02), Vector3(8.0, 0.0, 6.0 * sx))
        var fore := CylinderMesh.new()
        fore.top_radius = 0.03
        fore.bottom_radius = 0.022
        fore.height = 0.6
        _add_mesh(fore, skin, Vector3(0.33 * sx, 0.62, -0.1), Vector3(12.0, 0.0, 3.0 * sx))
        var palm := SphereMesh.new()
        palm.radius = 0.035
        palm.height = 0.07
        _add_mesh(palm, skin, Vector3(0.35 * sx, 0.3, -0.16))
        for fi in 5:
            var fing := CylinderMesh.new()
            fing.top_radius = 0.008
            fing.bottom_radius = 0.004
            fing.height = 0.17 if fi != 0 else 0.11
            _add_mesh(fing, skin, Vector3(0.35 * sx + (float(fi) - 2.0) * 0.016, 0.2, -0.17), Vector3(8.0, 0.0, (float(fi) - 2.0) * 5.0))

    # legs and feet
    for lx in [-1.0, 1.0]:
        var thigh := CylinderMesh.new()
        thigh.top_radius = 0.07
        thigh.bottom_radius = 0.05
        thigh.height = 0.45
        _add_mesh(thigh, skin, Vector3(0.11 * lx, 0.55, 0.0), Vector3(-4.0, 0.0, 0.0))
        var shin := CylinderMesh.new()
        shin.top_radius = 0.045
        shin.bottom_radius = 0.032
        shin.height = 0.4
        _add_mesh(shin, skin, Vector3(0.11 * lx, 0.2, 0.01), Vector3(4.0, 0.0, 0.0))
        var foot := BoxMesh.new()
        foot.size = Vector3(0.08, 0.04, 0.22)
        _add_mesh(foot, skin, Vector3(0.11 * lx, 0.02, -0.05))

    _step_audio = AudioStreamPlayer3D.new()
    _step_audio.stream = AudioBank.get_sound("footstep")
    _step_audio.unit_size = 8.0
    _step_audio.max_distance = 70.0
    _step_audio.volume_db = 3.0
    add_child(_step_audio)


func _add_mesh(mesh: Mesh, mat: Material, pos: Vector3, rot_deg: Vector3 = Vector3.ZERO, parent: Node3D = null) -> void:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.rotation_degrees = rot_deg
    mi.material_override = mat
    mi.position = pos
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    if parent != null:
        parent.add_child(mi)
    else:
        body_root.add_child(mi)


func start_chase(pos: Vector3, wait: float) -> void:
    global_position = pos
    visible = true
    mode = "chase"
    wait_left = wait
    gaze_time = 0.0


func show_apparition(pos: Vector3) -> void:
    global_position = pos
    visible = true
    mode = "apparition"
    gaze_time = 0.0


func hide_watcher() -> void:
    visible = false
    mode = "hidden"
    if observed:
        observed = false
        observed_changed.emit(false)


func _compute_observed() -> bool:
    var cam: Camera3D = player.camera
    var target: Vector3 = global_position + Vector3(0.0, 1.2, 0.0)
    var from: Vector3 = cam.global_position
    var to: Vector3 = target - from
    var dist: float = to.length()
    if dist < 0.1:
        return true
    if dist > 45.0:
        return false
    var fwd: Vector3 = -cam.global_transform.basis.z
    if rad_to_deg(fwd.angle_to(to)) > 36.0:
        return false
    var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
    var q := PhysicsRayQueryParameters3D.create(from, target)
    q.exclude = [player.get_rid()]
    var hit: Dictionary = space.intersect_ray(q)
    return hit.is_empty()


func _physics_process(delta: float) -> void:
    if mode == "hidden" or player == null:
        return

    var obs: bool = _compute_observed()
    if obs != observed:
        observed = obs
        observed_changed.emit(obs)

    var to_player: Vector3 = player.global_position - global_position
    to_player.y = 0.0
    var dist: float = to_player.length()
    if dist > 0.3:
        look_at(global_position + to_player, Vector3.UP)

    if mode != "chase":
        return

    if observed:
        gaze_time += delta
        GameManager.longest_gaze = maxf(GameManager.longest_gaze, gaze_time)
    else:
        gaze_time = 0.0

    if wait_left > 0.0:
        wait_left -= delta
        var pp: Vector3 = player.global_position
        if pp.x > 15.0 and absf(pp.z) < 1.9:
            wait_left = 0.0
        return

    if dist <= catch_distance:
        caught_player.emit()
        return

    if observed:
        return

    global_position += to_player.normalized() * speed * delta
    _step_timer -= delta
    if _step_timer <= 0.0:
        _step_timer = 0.42
        _step_audio.pitch_scale = randf_range(0.75, 0.95)
        _step_audio.volume_db = 3.0 + GameManager.audio_offset()
        _step_audio.play()


func _process(delta: float) -> void:
    _t += delta
    if visible and observed:
        body_root.rotation.z = randf_range(-0.03, 0.03)
        if _head_node != null:
            _head_node.rotation_degrees.z = randf_range(-6.0, 6.0)
    else:
        body_root.rotation.z = sin(_t * 0.9) * 0.012
        if _head_node != null:
            _head_node.rotation_degrees.z = lerpf(_head_node.rotation_degrees.z, sin(_t * 0.6) * 4.0, minf(delta * 3.0, 1.0))
    body_root.position.y = sin(_t * 1.6) * 0.008

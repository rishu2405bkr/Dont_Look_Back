extends OmniLight3D
# A ceiling light with a visible fixture that can flicker and be dimmed.

var fixture_mat: StandardMaterial3D = null
var emergency_energy: float = 0.4
var powered_energy: float = 1.1
var group: String = "corridor"
var base_energy: float = 0.4
var level: float = 1.0
var rest_level: float = 1.0
var _flicker_left: float = 0.0
var _change_in: float = 0.0
var hum: float = 0.0          # 0 = steady tube, higher = unstable fluorescent (mains hum + random dropouts)
var _t: float = 0.0


func set_power(on: bool) -> void:
    base_energy = powered_energy if on else emergency_energy
    set_level(level)


func set_level(f: float) -> void:
    level = f
    light_energy = base_energy * f
    if fixture_mat != null:
        fixture_mat.emission_energy_multiplier = 2.0 * f


func set_rest(f: float) -> void:
    rest_level = f
    if _flicker_left <= 0.0:
        set_level(f)


func flicker(duration: float = 1.2) -> void:
    _flicker_left = duration
    _change_in = 0.0


func _process(delta: float) -> void:
    _t += delta
    if _flicker_left <= 0.0:
        if hum > 0.0 and rest_level > 0.0 and base_energy > 0.0:
            var k: float = 1.0 - hum * 0.07 * (0.5 + 0.5 * sin(_t * 120.0)) * (0.6 + 0.4 * sin(_t * 5.3))
            set_level(rest_level * k)
            if randf() < 0.0012 * hum:
                flicker(randf_range(0.12, 0.45))
        return
    _flicker_left -= delta
    _change_in -= delta
    if _change_in <= 0.0:
        _change_in = randf_range(0.04, 0.13)
        set_level(0.0 if randf() < 0.55 else randf_range(0.4, 1.0))
    if _flicker_left <= 0.0:
        set_level(rest_level)

# Maker notes — Don't Look Back

Use this file to document your own work before presenting the project. Fill it in honestly; it is more convincing to explain specific design decisions than to claim that every part was made unaided.

## My design decisions
- Why I chose the “it moves when you look away” mechanic:
- Which room or story beat I designed/changed myself:
- A gameplay problem I found during testing:
- How I fixed it:
- One improvement I would make next:

## Play-test notes
| Tester (first name/initial only) | What confused them? | What felt tense? | Change made |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

## Submission integrity
Keep `docs/AI_DISCLOSURE.md` accurate for the actual process. If AI assistance was used, describe it briefly and clearly and explain what you personally directed, tested, edited, or implemented. Check the competition's policy before submitting.

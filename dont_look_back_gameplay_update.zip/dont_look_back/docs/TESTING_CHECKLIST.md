# Testing checklist
- [ ] Main menu: Enter Facility, Settings, Quit work; keyboard focus and mouse are usable
- [ ] Game starts: fade-in, mouse captured, WASD/mouse/Shift/Ctrl/F/E all work
- [ ] No falling through floor; walls and props block you
- [ ] Doors open (Security, Storage, Power); Lab is locked until power
- [ ] Notes open, close with E / Esc / click, and do not re-open instantly
- [ ] Fragments 1 and 2 collected; HUD slots light up; console needs 2
- [ ] Power restored: lights brighten, lab door unlocks
- [ ] Lab fragment starts the chase; Watcher is visible down the corridor
- [ ] Looking at the Watcher freezes it (crosshair turns blue); crosshair resets when it hides
- [ ] Getting caught fades out and returns you to a checkpoint; chase still winnable
- [ ] Exit refuses without 3 fragments + power; opens with them
- [ ] Both endings reachable; Play Again and Main Menu work
- [ ] Pause menu: Resume, Settings, Restart, Main Menu, Quit; game truly pauses
- [ ] Reduce audio / no shake / low-spec toggles take effect
- [ ] Restart several times: no errors, state resets
- [ ] Exported .exe runs standalone; frame rate acceptable


## Performance / submission pass
- [ ] Test at 1280×720 and one alternate window size.
- [ ] Test both default and Low-spec visuals on the presentation computer.
- [ ] Check all menu/pause buttons with mouse and keyboard focus.
- [ ] Check the game can be restarted repeatedly without duplicated audio or broken input.
- [ ] Export and test a clean build on a second account/computer if possible.
- [ ] Record any known issue rather than presenting it as tested/fixed.

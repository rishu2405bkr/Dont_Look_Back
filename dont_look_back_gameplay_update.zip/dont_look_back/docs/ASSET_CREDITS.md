# Asset credits
No external art, model, texture, font or audio files are used.
- 3D geometry: built from Godot primitives in code.
- Textures: a small noise texture generated in code.
- Sound: every sound effect is synthesized at runtime in `scripts/audio_bank.gd`.
- Font: Godot's default built-in font.
- Engine: Godot Engine (MIT License) - https://godotengine.org

The visual mood was inspired by a reference mood board supplied by the developer. No assets from it are used.

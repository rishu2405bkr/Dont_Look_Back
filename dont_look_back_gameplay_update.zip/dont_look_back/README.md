# DON'T LOOK BACK
A 3D first-person psychological horror game for Godot 4. About 5-10 minutes. Original code, text and audio.

## How to open
1. Unzip the folder.
2. Open Godot 4.x -> Project Manager -> **Import** -> select `project.godot` -> **Import & Edit**.
3. Wait for the first import to finish, then press **F5**.

Renderer: Forward+ (default). On a weak PC tick "Low-spec visuals" in Settings (turns off volumetric fog, glow, reflections, AO).

## Controls
WASD move - Mouse look - Shift run - Ctrl crouch - F flashlight - E interact - Esc pause

## How to play
Find the 3 access fragments (Security, Storage, Lab). Two of them restore power at the console in the Power Room.
The third fragment, in the Lab, starts the escape. The Watcher advances only while you are NOT looking at it.
Looking at it freezes it. Reach the main exit at the east end of the corridor.
Two endings: hold its gaze for 3 continuous seconds at any point during the escape for ending 1; otherwise ending 2.

## Graphics
Realism comes from code, not downloaded assets:
- 384x384 procedural PBR textures (albedo, normal, roughness, ambient-occlusion) for plaster (peeling paint, cracks, tide stains),
  wet tile (chips, scuffs, dirty grout), concrete, scratched/rusty metal, wood/crates (knots, nails) and Watcher skin;
  built in parallel threads. If "Preparing textures..." takes too long, lower `S` to 256 in `scripts/tex_gen.gd`.
- Lighting: shadow-casting lights with soft shadows, SSAO + SSIL (bounce light), screen-space reflections, reflection probes,
  clear-coated wet floor, volumetric fog + local fog volumes (red haze in the escape corridor), steam and dripping water particles,
  humming/unstable fluorescent tubes, MSAA 4x + TAA.
- Flashlight: projector beam texture (hot spot, lens rings), weak wide spill, hand-held inertia.
- Camera: head bob, breathing, strafe lean, sprint FOV kick; post-process with lens distortion, halation, split-toned grade,
  shadow-weighted sensor grain, dithering; fringing/vignette tighten as the Watcher closes in.
- Level dressing: ceiling beams, cable tray and cables, vents, extinguishers, conduits, floor drains, rubble, cracks, damp stains.
- The Watcher is now lit (skin shader, gown, hair, long fingers, breathing sway) instead of a flat black silhouette.
Needs the Forward+ renderer and a modern GPU for the full look; tick "Low-spec visuals" in Settings on weaker PCs.

## Accessibility
Settings: mouse sensitivity, master volume, reduce sudden audio, disable screen shake, low-spec visuals.

## Project layout
- `scripts/main_game.gd`  builds the whole facility from code and runs the game flow
- `scripts/horror_director.gd`  state-based events (footsteps, knocks, flicker, apparition, chase)
- `scripts/watcher.gd`  the creature (sight-based freeze mechanic)
- `scripts/audio_bank.gd`  all sounds are generated in code (no audio files)
- `scripts/story.gd`  all notes, recordings and endings

## Export (Windows)
Project -> Export -> Add... -> Windows Desktop -> download export templates if asked -> Export Project.
Test the .exe on its own before submitting.

## Current engine target
This project targets **Godot 4.7 stable** (tested target: 4.7.x, Forward+). Use the latest stable 4.7 maintenance release available from the official Godot download page; do not use the 4.8 beta for a judged submission unless your event specifically requires beta testing.

## Before submitting to a competition
- Run the full `docs/TESTING_CHECKLIST.md` on the actual computer you will present on.
- Personalise at least the opening message, one note/recording, and the ending text; keep a short changelog of what you designed and changed.
- Make sure the AI-use statement matches the real tools and assistance used and follow the competition's rules. Do not claim generated or assisted work was entirely unaided.
- Test the game after exporting it, not only inside the editor. Keep a backup copy of the project folder.
- This archive has not been run through the Godot editor in this environment, so treat runtime testing and export testing as still required.


## Expanded gameplay loop

- Explore the Security Office and Storage Room to find access fragments.
- Pick up the physical maintenance fuse in the Storage Room with **E**.
- Once you have two fragments and the fuse, return to the Power Room and interact with the console.
- Restoring power unlocks the Research Lab. Collect the third fragment, survive the Watcher chase, and unlock the main exit.
- Read notes and recordings for story clues; use crouching and sprinting thoughtfully rather than running everywhere.

The fuse is a world-space interactable with a collision shape, prompt, pickup feedback, and a state check at the power console. Please test the full progression in Godot before presenting the build.
